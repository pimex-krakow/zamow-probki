=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.7.2
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.7.2 =
Opcje producenta, koloru, konstrukcji i powłoki widać od razu po rozwinięciu filtra,
bez dodatkowej listy rozwijanej. Opisy wszystkich wymiarów przeniesiono do wnętrza.
Nagłówki filtrów mają szare tło, pogrubienie i boczny akcent; opcje białe tło.
Zachowano domyślne zwinięcie filtrów i otwarty zestaw na telefonie.
Szczegóły testów: AKTUALIZACJA-2.7.2.txt.
