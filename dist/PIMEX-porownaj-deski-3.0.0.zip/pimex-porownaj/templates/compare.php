<?php
defined('ABSPATH') || exit;
$view=($config['view']??'compare')==='samples'?'samples':'compare';
$fields=Pimex_Compare::ordered_filters($view);
$sampleSettings=$view==='samples'?($config['samples']??Pimex_Compare_Samples::config()):array();
$formPage=(int)get_queried_object_id()?:((int)Pimex_Compare::options()['page']);
?>
<pimex-compare-app style="display:block;width:100%" data-pimex-version="<?php echo esc_attr(Pimex_Compare::VERSION); ?>" data-view="<?php echo esc_attr($view); ?>">
<template shadowrootmode="open">
<?php echo Pimex_Compare::styles(); ?>
<section class="pmc-app" aria-label="<?php echo esc_attr($view==='samples'?'Zamów próbki PIMEX':'Porównaj deski PIMEX'); ?>">
<script type="application/json" class="pmc-config"><?php echo wp_json_encode($config,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
<header class="pmc-hero"><h2><?php echo $view==='samples'?'Zamów próbki desek':'Porównaj deski'; ?></h2><p><?php echo $view==='samples'?'Wybierz próbki materiału, sprawdź koszt zestawu i dodaj go do koszyka.':'Wybierz do 6 modeli i porównaj ich parametry.'; ?></p></header>
<?php if(empty($config['items'])){?><p class="pmc-message" role="status">Katalog jest przygotowywany. Zajrzyj tu ponownie lub zobacz <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">produkty w sklepie</a>.</p><?php } ?>
<?php if($view==='samples'){ ?><p class="pmc-hint" style="margin-bottom:12px">Filtry ceny za mb i m² dotyczą pełnej deski. Cena przy próbce dotyczy jednej próbki materiału.</p><?php } ?>
<div class="pmc-layout">
<aside class="pmc-sidebar" aria-label="Filtry produktów">
<div class="pmc-category-picker" role="group" aria-label="Rodzaj desek">
<div class="pmc-category-options">
<button type="button" data-category="Deski tarasowe" aria-pressed="false">Deski tarasowe</button>
<button type="button" data-category="Deski elewacyjne" aria-pressed="false">Deski elewacyjne</button>
<button type="button" data-category="Lamele elewacyjne" aria-pressed="false">Lamele elewacyjne</button>
</div>
<button type="button" class="pmc-category-all" data-category="" hidden>Pokaż wszystkie</button>
</div>
<details class="pmc-filters"><summary>Filtry <span class="pmc-filter-count"></span></summary><div class="pmc-filter-content">
<?php foreach($fields as $field=>$label){ if(strpos($field,'price_')===0){ $unit=substr($field,6); ?>
<details class="pmc-rate-filter" data-unit="<?php echo esc_attr($unit); ?>"><summary><?php echo esc_html($label); ?></summary>
<div class="pmc-range" role="group" aria-label="<?php echo esc_attr($label.' — suwaki zakresu'); ?>">
<label class="pmc-range-label">Zakres: <output data-range-label="<?php echo esc_attr($unit); ?>">Pobieranie zakresu cen…</output></label>
<div class="pmc-range-track">
<input type="range" min="0" max="1" step="0.01" value="0" data-slider="<?php echo esc_attr($unit); ?>" data-bound="min" aria-label="<?php echo esc_attr($label.' — minimum'); ?>" disabled>
<input type="range" min="0" max="1" step="0.01" value="1" data-slider="<?php echo esc_attr($unit); ?>" data-bound="max" aria-label="<?php echo esc_attr($label.' — maksimum'); ?>" disabled>
</div></div>
<div class="pmc-rate-fields">
<label>Od <input type="number" min="0" step="0.01" inputmode="decimal" data-rate="<?php echo esc_attr($unit); ?>" data-bound="min" aria-label="<?php echo esc_attr($label.' od'); ?>" placeholder="Bez minimum"></label>
<label>Do <input type="number" min="0" step="0.01" inputmode="decimal" data-rate="<?php echo esc_attr($unit); ?>" data-bound="max" aria-label="<?php echo esc_attr($label.' do'); ?>" placeholder="Bez maksimum"></label>
<span>zł / <?php echo esc_html($unit==='mb'?'mb':'m²'); ?></span>
</div></details>
<?php }else{ ?><details class="pmc-filter" data-field="<?php echo esc_attr($field); ?>"><summary><?php echo esc_html($label); ?><span class="pmc-option-count"></span></summary><div class="pmc-options" role="group" aria-label="<?php echo esc_attr($label); ?>"></div></details><?php }} ?>
<p class="pmc-rate-status" role="status" aria-live="polite"></p><button type="button" class="pmc-rate-retry" hidden>Spróbuj pobrać ceny ponownie</button>
<p class="pmc-hint">Cena za m² wg szerokości krycia, a przy jej braku wg szerokości deski. Model pasuje, gdy jedna z jego długości mieści się w wybranych zakresach.</p>
<p class="pmc-hint">Wymiary w mm. Możesz zaznaczyć kilka opcji. Produkcja na wymiar pasuje do każdej długości.</p>
<button type="button" class="pmc-reset">Wyczyść filtry</button>
</div></details>
</aside>
<div class="pmc-catalog">
<div class="pmc-toolbar"><p class="pmc-results" aria-live="polite"></p><div class="pmc-tools">
<button type="button" class="pmc-search-toggle" aria-label="Szukaj produktów" aria-expanded="false"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 5 5"></path></svg></button>
<button type="button" class="pmc-reset">Wyczyść filtry</button>
<?php if($view==='compare'){ ?><button type="button" class="pmc-clear" disabled>Wyczyść wybór</button><?php }else{ ?><button type="button" class="pmc-sample-clear" disabled>Wyczyść zestaw</button><?php } ?>
</div></div>
<div class="pmc-search-box" hidden><input type="search" class="pmc-search" aria-label="Model, producent lub kolor" placeholder="Szukaj modelu, producenta lub koloru" autocomplete="off"></div>
<div class="pmc-chips" aria-label="Aktywne filtry" hidden></div>
<div class="pmc-quick-selection">
<?php if($view==='compare'){ ?><strong class="pmc-quick-count">Wybrano 0 z 6</strong><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button><?php }else{ ?><strong class="pmc-sample-top-count">Próbki: 0 szt.</strong><button type="button" class="pmc-open-samples pmc-primary" disabled>Zobacz zestaw (0)</button><?php } ?>
</div>
<div class="pmc-grid"></div>
<div class="pmc-empty" hidden><h3>Brak produktów spełniających te warunki</h3><p>Zmień filtry lub wyszukiwane hasło.</p><button type="button" class="pmc-reset">Pokaż wszystkie produkty</button></div>
<nav class="pmc-pages" aria-label="Strony produktów"></nav>
</div></div>
<?php if($view==='compare'){ ?>
<section class="pmc-comparison" hidden aria-label="Porównanie produktów">
<div class="pmc-table-toolbar"><h2 tabindex="-1">Porównanie produktów</h2><button type="button" class="pmc-close-table">Wróć do wyboru</button></div>
<div class="pmc-table-navigation"><button type="button" class="pmc-table-prev" aria-label="Poprzednie produkty">←</button><p class="pmc-table-hint">Przesuń tabelę palcem lub użyj strzałek.<span class="pmc-table-position" aria-live="polite"></span></p><button type="button" class="pmc-table-next" aria-label="Kolejne produkty">→</button></div>
<div class="pmc-table-scroll" tabindex="0" role="region" aria-label="Tabela porównania produktów"></div>
<p class="pmc-hint">Ceny i dostępność mogą się zmienić. Ostateczne warunki sprawdzisz na karcie produktu. Brak danych oznacza brak odpowiedniego atrybutu w sklepie.</p>
</section>
<div class="pmc-summaries"><section class="pmc-selection" aria-label="Produkty do porównania">
<h3>Porównanie</h3><strong class="pmc-selected-count">Wybrano 0 z 6</strong><ul class="pmc-selected"></ul><div class="pmc-selection-actions"><button type="button" class="pmc-clear" disabled>Wyczyść porównanie</button><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button><a class="pmc-transfer" href="#" aria-disabled="true">Zamów próbki wybranych desek</a></div>
</section></div>
<?php }else{ ?>
<div class="pmc-summaries"><form method="post" class="pmc-sample-order" action="<?php echo esc_url(get_permalink($formPage)); ?>">
<input type="hidden" name="pimex_compare_samples_action" value="add">
<input type="hidden" name="pimex_compare_samples_nonce" class="pmc-sample-nonce" value="<?php echo esc_attr($sampleSettings['nonce']); ?>">
<input type="hidden" name="pimex_compare_samples_ids" class="pmc-sample-ids" value="[]">
<h3 tabindex="-1">Zestaw próbek <span class="pmc-sample-count">0 szt.</span></h3>
<p class="pmc-sample-empty">Dodaj próbki wybranych desek. Wybór próbek jest niezależny od porównania.</p>
<ul class="pmc-sample-selected"></ul>
<div class="pmc-sample-totals" aria-live="polite"><p><span class="pmc-sample-quantity">Próbki · 0 szt.</span><strong class="pmc-sample-subtotal">—</strong></p><p><span>Wysyłka w Polsce</span><strong class="pmc-sample-shipping">—</strong></p><p><span>Razem brutto</span><strong class="pmc-sample-total">—</strong></p></div>
<p class="pmc-sample-status" role="status" aria-live="polite"></p>
<button type="button" class="pmc-sample-retry" hidden>Sprawdź próbki ponownie</button>
<div class="pmc-sample-actions"><button type="button" class="pmc-sample-clear" disabled>Wyczyść próbki</button><button type="submit" class="pmc-sample-submit pmc-primary" disabled>Zamów próbki</button></div>
<p class="pmc-hint">Zestaw trafi do koszyka. <span class="pmc-sample-limit"></span> Zdjęcia przedstawiają produkty; zamawiasz próbki materiału.</p>
</form></div>
<?php } ?>
<div class="pmc-mobile-dock" hidden aria-label="<?php echo esc_attr($view==='samples'?'Zestaw próbek':'Porównanie produktów'); ?>">
<?php if($view==='compare'){ ?><strong class="pmc-dock-count pmc-sr-only">Wybrano 0 z 6</strong><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button><?php }else{ ?><button type="button" class="pmc-open-samples pmc-primary" disabled>Zobacz zestaw (0)</button><?php } ?>
</div>
<p class="pmc-feedback" role="status" aria-live="polite"></p>
</section>
</template>
<noscript><p>Włącz JavaScript, aby korzystać z filtrów i wyboru produktów. Produkty są dostępne także w sklepie.</p></noscript>
</pimex-compare-app>
