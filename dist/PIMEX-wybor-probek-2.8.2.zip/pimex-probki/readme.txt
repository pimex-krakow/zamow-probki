=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.8.2
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.8.2 =
Kompaktowe filtry na telefonie: jeden nagłówek, kafelki w dwóch kolumnach,
białe tło, zielona ramka i jednolite małe checkboxy w opcjach.
Reset obsługuje podmieniane przyciski, blokowanie zdarzeń przez motyw i oczekujące wyszukiwanie.
Przekierowanie produktu technicznego pozostawione do konfiguracji w Redirection.
Zachowano noindex i wykluczenia z map. Usunięto zdanie o transporcie pełnych desek.
Szczegóły testów: AKTUALIZACJA-2.8.2.txt.
