=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 3.0.6
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Odizolowany responsywny
interfejs, filtry atrybutów, niezależna dostępność, edytowalne ceny,
podsumowanie i osobna dostawa zestawu. Zachowuje ustawienia poprzedniej wersji.

== Installation ==
Prześlij ZIP i zastąp istniejącą wtyczkę. Zachowaj stronę [pimex_probki]
i produkt techniczny. Ustawienia: WooCommerce > Próbki PIMEX.
Po aktualizacji wyczyść cache strony i przeglądarki.

== Changelog ==
= 3.0.6 =
Typ elementu w osobnym wierszu bezpośrednio nad serią, z takim samym stylem.
Usunięty zbędny odstęp przed kolorem. Zachowane optymalizacje 3.0.2.
Szczegóły: AKTUALIZACJA-3.0.6.txt.
