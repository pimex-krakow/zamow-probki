<?php
/** One filter component and an isolated responsive view. */
defined('ABSPATH') || exit;
$groups = array('' => 'Wszystkie próbki', 'tarasy' => 'Deski tarasowe', 'elewacje' => 'Deski elewacyjne', 'lamele' => 'Lamele elewacyjne');
$fields = array(
    array('Zastosowanie', 'pms-groups', $groups),
    array('Producent', 'pms-brand', array()),
    array('Kolor', 'pms-color-filter', array('' => 'Wszystkie kolory') + Pimex_Samples_Catalog::shades()),
    array('Konstrukcja', 'pms-construction', array('' => 'Wszystkie konstrukcje', 'solid' => 'Pełna', 'hollow' => 'Komorowa')),
    array('Powłoka', 'pms-coating', array('' => 'Wszystkie', 'coated' => 'Z powłoką polimerową', 'uncoated' => 'Bez powłoki polimerowej')),
    array('Powierzchnia', 'pms-surface', array()),
    array('Materiał', 'pms-material', array()),
    array('Szerokość deski', 'width', null),
    array('Długość deski', 'length', null),
    array('Grubość deski', 'thickness', null)
);
?>
<pimex-samples-app style="display:block;width:100%" data-pimex-ui-version="3.0.0">
<template shadowrootmode="open" data-pimex-view="3.0.0">
<?php echo Pimex_Samples_1::view_styles(); ?>
<section class="pimex-samples pms-app" aria-label="Wybór próbek PIMEX">
    <script type="application/json" class="pms-config"><?php echo wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
    <header class="pms-hero"><h2>Sprawdź materiał przed zakupem</h2><p>Porównaj kolory i strukturę w swoim domu. Zaznacz próbki, które chcesz zamówić.</p></header>
    <?php if (!$config['enabled']) : ?><p class="pms-status" role="status">Zamawianie próbek jest chwilowo wyłączone. Możesz obejrzeć dostępne materiały.</p><?php endif; ?>
    <div class="pms-layout">
        <aside class="pms-filter-panel" aria-label="Filtry próbek">
            <details class="pms-mobile-filters"><summary>Filtry<span class="pms-more-count"></span></summary>
                <div class="pms-filter-content">
                <?php foreach ($fields as $field) : $dimension = $field[2] === null; ?>
                    <details class="pms-filter-section<?php echo $dimension ? ' pms-dimension' : ''; ?>"<?php if ($dimension) : ?> data-axis="<?php echo esc_attr($field[1]); ?>"<?php endif; ?>>
                        <summary class="pms-filter-heading"><span class="pms-filter-title"><?php echo esc_html($field[0]); ?></span></summary>
                        <?php if ($dimension) : ?><span class="pms-dimension-value" hidden></span><?php endif; ?>
                        <div class="pms-filter-options <?php echo $dimension ? 'pms-dimension-options' : esc_attr($field[1]); ?>" role="group" aria-label="<?php echo esc_attr($field[0]); ?>">
                            <?php foreach ((array) $field[2] as $value => $label) : ?>
                                <label class="pms-dimension-option"><input type="checkbox" value="<?php echo esc_attr($value); ?>"<?php if ($value === '') : ?> checked<?php endif; ?>><span><?php echo esc_html($label); ?><?php if ($field[1] === 'pms-groups') : ?> <small class="pms-group-count"></small><?php endif; ?></span></label>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endforeach; ?>
                    <p>Wymiary w mm. Możesz wybrać kilka opcji. Deski na wymiar pasują do każdej długości. Zamawiasz próbkę materiału.</p>
                    <button type="button" class="pms-reset-filters">Wyczyść filtry</button>
                </div>
            </details>
        </aside>
        <div class="pms-catalog">
            <div class="pms-result-line"><p class="pms-results" aria-live="polite"></p><div class="pms-catalog-tools">
                <button type="button" class="pms-search-toggle" aria-label="Szukaj próbek" title="Szukaj próbek" aria-expanded="false"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 5 5"></path></svg></button>
                <button type="button" class="pms-reset-filters">Wyczyść filtry</button>
            </div></div>
            <div class="pms-search-box" hidden><input class="pms-search" type="search" aria-label="Model, producent lub kolor" placeholder="Szukaj modelu, producenta lub koloru" autocomplete="off"></div>
            <div class="pms-active-filters" aria-label="Aktywne filtry" hidden></div>
            <div class="pms-grid"></div>
            <div class="pms-empty" hidden><h3>Nie znaleźliśmy takich próbek</h3><p>Zmień model, producenta, kolor lub zastosowanie.</p><button type="button" class="pms-reset-filters">Pokaż wszystkie próbki</button></div>
            <nav class="pms-pagination" aria-label="Strony wyboru próbek"></nav>
            <p class="pms-photo-note">Zdjęcia przedstawiają pełny produkt lub realizację. Otrzymasz próbkę materiału. Kolor na ekranie może różnić się od rzeczywistego.</p>
        </div>
        <form method="post" class="pms-order" action="<?php echo esc_url(get_permalink()); ?>">
            <?php wp_nonce_field('pimex_samples_order', 'pimex_samples_nonce'); ?>
            <input type="hidden" name="pimex_samples_action" value="add"><input type="hidden" name="pimex_samples_ids" value="[]" class="pms-ids">
            <div class="pms-details"><div class="pms-summary-heading"><h3>Twój zestaw</h3><span class="pms-count" aria-label="Liczba wybranych próbek">0</span></div>
                <div class="pms-summary-body">
                    <p class="pms-empty-selection">Zaznacz pierwszą próbkę. Możesz łączyć materiały różnych producentów.</p>
                    <ul class="pms-selected"></ul>
                    <div class="pms-totals" aria-live="polite"><p><span class="pms-quantity-label">Próbki · 0 szt.</span><strong class="pms-subtotal">0,00 zł</strong></p><p><span>Wysyłka w Polsce</span><strong class="pms-shipping">—</strong></p><p class="pms-total-row"><span>Razem brutto</span><strong class="pms-grand-total">0,00 zł</strong></p></div>
                    <p class="pms-feedback" role="status" aria-live="polite"></p>
                    <button type="submit" class="pms-submit" disabled>Dodaj zestaw do koszyka →</button><button type="button" class="pms-clear">Wyczyść zestaw</button>
                    <p class="pms-note">Maksymalnie <?php echo esc_html($config['max']); ?> różnych próbek, po jednej sztuce każdego modelu i koloru.</p>
                </div>
            </div>
        </form>
    </div>
</section>
</template>
<noscript><p>Włącz JavaScript, aby wybrać próbki. Możesz też skontaktować się z PIMEX w sprawie zamówienia.</p></noscript>
</pimex-samples-app>
