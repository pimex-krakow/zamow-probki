<?php
defined('ABSPATH') || exit;
$fields=array('application'=>'Zastosowanie','brand'=>'Producent','shade'=>'Kolor','type'=>'Typ elementu','material'=>'Materiał','construction'=>'Konstrukcja','coating'=>'Powłoka','surface'=>'Powierzchnia','width'=>'Szerokość','length'=>'Długość','thickness'=>'Grubość');
?>
<pimex-compare-app style="display:block;width:100%">
<template shadowrootmode="open">
<?php echo Pimex_Compare::styles(); ?>
<section class="pmc-app" aria-label="Porównaj deski PIMEX">
<script type="application/json" class="pmc-config"><?php echo wp_json_encode($config,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
<header class="pmc-hero"><h2>Porównaj deski</h2><p>Wybierz do 4 produktów i porównaj ich parametry.</p></header>
<?php if(empty($config['items'])){?><p class="pmc-message" role="status">Katalog porównania jest przygotowywany. Zajrzyj tu ponownie lub zobacz <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">produkty w sklepie</a>.</p><?php } ?>
<div class="pmc-layout">
<aside class="pmc-sidebar" aria-label="Filtry produktów">
<details class="pmc-filters"><summary>Filtry <span class="pmc-filter-count"></span></summary><div class="pmc-filter-content">
<?php foreach($fields as $field=>$label){?><details class="pmc-filter" data-field="<?php echo esc_attr($field); ?>"><summary><?php echo esc_html($label); ?><span class="pmc-option-count"></span></summary><div class="pmc-options" role="group" aria-label="<?php echo esc_attr($label); ?>"></div></details><?php } ?>
<p class="pmc-hint">Wymiary w mm. Możesz zaznaczyć kilka opcji. Produkcja na wymiar pasuje do każdej długości.</p>
<button type="button" class="pmc-reset">Wyczyść filtry</button>
</div></details>
</aside>
<div class="pmc-catalog">
<div class="pmc-toolbar"><p class="pmc-results" aria-live="polite"></p><div class="pmc-tools">
<button type="button" class="pmc-search-toggle" aria-label="Szukaj produktów" aria-expanded="false"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 5 5"></path></svg></button>
<button type="button" class="pmc-reset">Wyczyść filtry</button>
</div></div>
<div class="pmc-search-box" hidden><input type="search" class="pmc-search" aria-label="Model, producent lub kolor" placeholder="Szukaj modelu, producenta lub koloru" autocomplete="off"></div>
<div class="pmc-chips" aria-label="Aktywne filtry" hidden></div>
<div class="pmc-grid"></div>
<div class="pmc-empty" hidden><h3>Brak produktów spełniających te warunki</h3><p>Zmień filtry lub wyszukiwane hasło.</p><button type="button" class="pmc-reset">Pokaż wszystkie produkty</button></div>
<nav class="pmc-pages" aria-label="Strony produktów"></nav>
</div></div>
<div class="pmc-selection" aria-label="Produkty do porównania">
<strong class="pmc-selected-count">Wybrano 0 z 4</strong><ul class="pmc-selected"></ul><div class="pmc-selection-actions"><button type="button" class="pmc-clear">Wyczyść</button><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button></div>
</div>
<p class="pmc-feedback" role="status" aria-live="polite"></p>
<section class="pmc-comparison" hidden aria-label="Porównanie produktów">
<div class="pmc-table-toolbar"><h2 tabindex="-1">Porównanie produktów</h2><label class="pmc-option"><input type="checkbox" class="pmc-differences"><span>Pokaż tylko różnice</span></label><button type="button" class="pmc-close-table">Wróć do wyboru</button></div>
<p class="pmc-table-hint">Na telefonie przesuń tabelę w bok, aby zobaczyć kolejne produkty.</p>
<div class="pmc-table-scroll" tabindex="0" role="region" aria-label="Tabela porównania produktów"></div>
<p class="pmc-identical" hidden>Porównywane produkty mają takie same wartości dostępnych parametrów.</p>
<p class="pmc-hint">Ceny i dostępność mogą się zmienić. Ostateczne warunki sprawdzisz na karcie produktu. Brak danych oznacza brak odpowiedniego atrybutu w sklepie.</p>
</section>
</section>
</template>
<noscript><p>Włącz JavaScript, aby filtrować i porównywać deski. Produkty są dostępne także w sklepie.</p></noscript>
</pimex-compare-app>
