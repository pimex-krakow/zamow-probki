<?php
/**
 * Plugin Name: PIMEX — porównaj deski
 * Description: Oddzielna porównywarka desek z filtrami atrybutów i integracją grup kolorów PIMEX.
 * Version: 1.0.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: PIMEX
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes/attributes.php';
require_once __DIR__ . '/includes/catalog.php';
require_once __DIR__ . '/includes/admin.php';
final class Pimex_Compare {
    const VERSION = '1.0.0';
    const OPTION = 'pimex_compare_settings';
    public static function boot() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', function() { echo '<div class="notice notice-error"><p>PIMEX — porównaj deski wymaga aktywnego WooCommerce.</p></div>'; });
            return;
        }
        add_shortcode('pimex_porownaj', array(__CLASS__, 'shortcode'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('pimex_compare_build', array('Pimex_Compare_Catalog', 'batch'));
        foreach (array('save_post_product','save_post_product_variation','woocommerce_new_product','woocommerce_update_product','woocommerce_new_product_variation','woocommerce_update_product_variation') as $hook) {
            add_action($hook, array('Pimex_Compare_Catalog', 'changed_product'));
        }
        add_action('deleted_post', array('Pimex_Compare_Catalog', 'deleted_post'), 10, 2);
        foreach (array('created_term','edited_term','delete_term') as $hook) {
            add_action($hook, array('Pimex_Compare_Catalog', 'changed_term'), 10, 3);
        }
        add_action('set_object_terms', function($id,$terms,$tt_ids,$taxonomy) { Pimex_Compare_Catalog::changed_term(0,0,$taxonomy); }, 10, 4);
        add_action('updated_option', array('Pimex_Compare_Catalog', 'changed_option'), 10, 3);
        add_action('added_option', array('Pimex_Compare_Catalog', 'added_option'), 10, 2);
        add_action('wp_ajax_pimex_compare_prices', array(__CLASS__, 'prices'));
        add_action('wp_ajax_nopriv_pimex_compare_prices', array(__CLASS__, 'prices'));
        Pimex_Compare_Admin::boot();
    }
    public static function options() {
        return wp_parse_args((array) get_option(self::OPTION, array()), array('categories'=>array('deski-kompozytowe','deski-drewniane','kompozytowe-elewacje','lamele-kompozytowe'), 'page'=>0));
    }
    public static function assets() {
        $post = get_post();
        if ($post && (has_shortcode($post->post_content, 'pimex_porownaj') || (int) $post->ID === (int) self::options()['page'])) { self::enqueue(); }
    }
    private static function enqueue() {
        wp_enqueue_script('pimex-compare-100', plugins_url('assets/app-1.0.0.min.js', __FILE__), array(), self::VERSION, true);
    }
    public static function styles() {
        static $css = null;
        if ($css === null) { $css = file_get_contents(__DIR__.'/assets/app-1.0.0.min.css'); }
        return '<style>'.$css.'</style>';
    }
    public static function shortcode() {
        self::enqueue();
        $snapshot = Pimex_Compare_Catalog::snapshot();
        $config = array('items'=>$snapshot['items'] ?? array(), 'limit'=>4, 'pageSize'=>18,
            'priceUrl'=>wp_make_link_relative(admin_url('admin-ajax.php')), 'storage'=>'pimex-compare:'.get_current_blog_id());
        ob_start(); include __DIR__.'/templates/compare.php'; return ob_get_clean();
    }
    /** Public read-only, bounded endpoint. No mutations, cart or client-supplied prices. */
    public static function prices() {
        $raw = isset($_POST['ids']) && is_string($_POST['ids']) ? wp_unslash($_POST['ids']) : '';
        if (strlen($raw) > 800) { wp_send_json_error(array('message'=>'Za dużo produktów.'), 400); }
        $ids = array_values(array_unique(wp_parse_id_list($raw)));
        if (count($ids) > 24) { wp_send_json_error(array('message'=>'Za dużo produktów.'), 400); }
        $result = array();
        foreach ($ids as $id) {
            $product = wc_get_product($id);
            if (!$product || !Pimex_Compare_Catalog::allowed($product)) { continue; }
            $html = $product->get_price_html();
            $html = preg_replace('/<del\b[^>]*>.*?<\/del>/is', '', $html);
            $html = preg_replace('/<span\b[^>]*class=[\"\'][^\"\']*screen-reader-text[^\"\']*[\"\'][^>]*>.*?<\/span>/is', '', $html);
            $result[(string) $id] = array('price'=>trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES, 'UTF-8'))),
                'stock'=>$product->get_stock_status(), 'purchasable'=>$product->is_purchasable());
        }
        nocache_headers(); wp_send_json_success($result);
    }
}
add_action('plugins_loaded', array('Pimex_Compare', 'boot'));
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('pimex_compare_build');
    delete_option(Pimex_Compare_Catalog::BUILD);
    delete_option('pimex_compare_lock');
});
