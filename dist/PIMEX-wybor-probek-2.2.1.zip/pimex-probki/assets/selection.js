(function (root, factory) {
    'use strict';
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.PimexSampleSelection = factory();
}(typeof window !== 'undefined' ? window : globalThis, function () {
    'use strict';
    function normalized(text) {
        return String(text || '').toLocaleLowerCase('pl').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ł/g, 'l');
    }
    class Selection {
        constructor(items, limit) {
            this.items = Array.isArray(items) ? items : [];
            this.limit = Math.max(1, Number(limit) || 12);
            this.byKey = new Map();
            this.byId = new Map();
            this.items.forEach(item => { this.byKey.set(item.key, item); this.byId.set(Number(item.id), item); });
            this.selected = new Set();
        }
        choose(key, on) {
            if (!this.byKey.has(key)) return { ok: false, reason: 'missing' };
            if (on && !this.selected.has(key) && this.selected.size >= this.limit) return { ok: false, reason: 'limit' };
            if (on) this.selected.add(key); else this.selected.delete(key);
            return { ok: true };
        }
        restore(saved) {
            if (!Array.isArray(saved)) return;
            saved.slice(0, 500).forEach(value => {
                const item = typeof value === 'string' ? this.byKey.get(value) : this.byId.get(Number(value));
                if (item) this.choose(item.key, true);
            });
        }
        entries() { return Array.from(this.selected, key => this.byKey.get(key)).filter(Boolean); }
        ids() { return this.entries().map(item => Number(item.id)); }
        totals() {
            const count = this.selected.size;
            return { count, subtotal: count * 4, shipping: count ? 14 : 0, total: count ? count * 4 + 14 : 0 };
        }
        filter(filters) {
            const f = filters || {}, query = normalized(f.search).trim().split(/\s+/).filter(Boolean);
            return this.items.filter(item => (!f.group || item.group === f.group)
                && (!f.brand || item.brand === f.brand) && (!f.color || (item.shades || []).includes(f.color))
                && (!f.construction || item.construction === f.construction)
                && (!f.coating || item.coating === f.coating)
                && ['width', 'length'].every(axis => !f[axis] || !f[axis].length || (item[axis + 's'] || []).some(value => f[axis].includes(value)))
                && query.every(word => normalized([item.label, item.brand, item.color, item.sku, item.series].join(' ')).includes(word)));
        }
    }
    return { Selection, normalized };
}));
