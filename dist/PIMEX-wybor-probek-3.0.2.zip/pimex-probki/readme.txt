=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 3.0.2
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Odizolowany responsywny
interfejs, filtry atrybutów, niezależna dostępność, edytowalne ceny,
podsumowanie i osobna dostawa zestawu. Zachowuje ustawienia poprzedniej wersji.

== Installation ==
Prześlij ZIP i zastąp istniejącą wtyczkę. Zachowaj stronę [pimex_probki]
i produkt techniczny. Ustawienia: WooCommerce > Próbki PIMEX.
Po aktualizacji wyczyść cache strony i przeglądarki.

== Changelog ==
= 3.0.2 =
Jeden mniejszy skrypt widoku i odchudzone dane przeglądarki.
Ponowne używanie kafelków, mniejsza liczba aktualizacji podsumowania
oraz wspólne formatowanie liczb. Zachowany wygląd i układ przycisków 3.0.1.
Szczegóły pomiarów i testów: AKTUALIZACJA-3.0.2.txt.
