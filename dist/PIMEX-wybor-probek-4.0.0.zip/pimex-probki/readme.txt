=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 4.0.0
License: GPLv2 or later

== Description ==
Dwie osobne strony: porównanie desek i zamawianie próbek. Wspólny wygląd
oraz rodzaje filtrów, niezależny wybór filtrów i ich kolejności w WooCommerce.
Porównanie ma osobny wybór wierszy tabeli, próbki własną dostępność.

== Installation ==
Zaktualizuj obie paczki: Porównaj deski 3.0.0 oraz Wybór próbek 4.0.0.
Instrukcja krok po kroku: START-TUTAJ.txt. Raz odśwież wspólny katalog.
Zachowaj dwie strony: [pimex_porownaj] oraz [pimex_probki].

== Changelog ==
= 4.0.0 =
Osobne widoki i ustawienia, wspólny interfejs. Przygotowany katalog,
odczyty porcjami i ładowanie zasobów selektora tylko na stronach narzędzi.
Szczegóły i ograniczenia testów: INSTRUKCJA.txt oraz TESTY.txt.
