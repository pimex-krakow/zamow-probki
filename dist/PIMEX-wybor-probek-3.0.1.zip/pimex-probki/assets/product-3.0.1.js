(function () {
    'use strict';
    const observedForms = new WeakSet();
    function alignButtons(form) {
        const sample = form.querySelector('button.pimex-sample-cta[data-pimex-direct-url]');
        const add = form.querySelector('button.single_add_to_cart_button');
        if (!sample || !add || sample.form !== form || add.form !== form) return;
        const existing = add.closest('.pimex-purchase-actions');
        if (existing && sample.parentElement === existing) return;
        const container = add.closest('.woocommerce-variation-add-to-cart') || form;
        let anchor = add;
        while (anchor.parentElement !== container) anchor = anchor.parentElement;
        const row = document.createElement('div'); row.className = 'pimex-purchase-actions';
        if (anchor === add) anchor.before(row); else anchor.after(row);
        row.append(add, sample);
    }
    function prepare() {
        document.querySelectorAll('button.pimex-sample-cta[data-pimex-direct-url]').forEach(function (sample) {
            const form = sample.form; if (!form) return;
            alignButtons(form);
            if (!observedForms.has(form) && window.MutationObserver) {
                observedForms.add(form);
                new MutationObserver(() => alignButtons(form)).observe(form, {childList:true, subtree:true});
            }
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', prepare); else prepare();
    // Submit only sample data. Theme AJAX handlers must never add a full board for this button.
    document.addEventListener('click', function (event) {
        const button = event.target.closest('button.pimex-sample-cta[data-pimex-direct-url]');
        if (!button || !button.form) return;
        event.preventDefault(); event.stopImmediatePropagation();
        if (button.disabled) return;
        const source = button.form;
        const form = document.createElement('form');
        form.method = 'post'; form.action = button.dataset.pimexDirectUrl; form.hidden = true;
        const fields = {
            pimex_samples_direct: button.value,
            pimex_sample_direct_nonce: (source.querySelector('[name="pimex_sample_direct_nonce"]') || {}).value || '',
            variation_id: (source.querySelector('[name="variation_id"]') || {}).value || '0'
        };
        Object.keys(fields).forEach(function (name) {
            const input = document.createElement('input'); input.type = 'hidden'; input.name = name; input.value = fields[name]; form.append(input);
        });
        button.disabled = true;
        document.body.append(form); form.submit();
    }, true);
    window.addEventListener('pageshow', function () {
        document.querySelectorAll('button.pimex-sample-cta').forEach(button => { button.disabled = false; });
    });
}());
