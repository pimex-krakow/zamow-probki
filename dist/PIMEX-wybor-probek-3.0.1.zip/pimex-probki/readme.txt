=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 3.0.1
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Odizolowany responsywny
interfejs, filtry atrybutów, niezależna dostępność, edytowalne ceny,
podsumowanie i osobna dostawa zestawu. Zachowuje ustawienia poprzedniej wersji.

== Installation ==
Prześlij ZIP i zastąp istniejącą wtyczkę. Zachowaj stronę [pimex_probki]
i produkt techniczny. Ustawienia: WooCommerce > Próbki PIMEX.
Po aktualizacji wyczyść cache strony i przeglądarki.

== Changelog ==
= 3.0.1 =
Przyciski Dodaj do koszyka i Zamów próbkę pozostają w jednym wierszu także na telefonie.
Przycisk próbki jest po prawej, biały z zielonym obramowaniem.
Układ przywracany po odświeżeniu wariantu przez motyw.
Zachowano bezpośrednie dodawanie próbki i interfejs 3.0.
Szczegóły testów: AKTUALIZACJA-3.0.1.txt.
