<?php
/**
 * Plugin Name: PIMEX — porównaj deski
 * Description: Oddzielna porównywarka desek z filtrami atrybutów i integracją grup kolorów PIMEX.
 * Version: 1.4.2
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: PIMEX
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes/attributes.php';
require_once __DIR__ . '/includes/catalog.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/seo.php';
require_once __DIR__ . '/includes/rates.php';
final class Pimex_Compare {
    const VERSION = '1.4.2';
    const OPTION = 'pimex_compare_settings';
    public static function boot() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', function() { echo '<div class="notice notice-error"><p>PIMEX — dobierz i porównaj deski wymaga aktywnego WooCommerce.</p></div>'; });
            return;
        }
        add_shortcode('pimex_porownaj', array(__CLASS__, 'shortcode'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('pimex_compare_build', array('Pimex_Compare_Catalog', 'batch'));
        foreach (array('save_post_product','save_post_product_variation','woocommerce_new_product','woocommerce_update_product','woocommerce_new_product_variation','woocommerce_update_product_variation') as $hook) {
            add_action($hook, array('Pimex_Compare_Catalog', 'changed_product'));
        }
        add_action('deleted_post', array('Pimex_Compare_Catalog', 'deleted_post'), 10, 2);
        foreach (array('created_term','edited_term','delete_term') as $hook) {
            add_action($hook, array('Pimex_Compare_Catalog', 'changed_term'), 10, 3);
        }
        add_action('set_object_terms', function($id,$terms,$tt_ids,$taxonomy) { Pimex_Compare_Catalog::changed_term(0,0,$taxonomy); }, 10, 4);
        add_action('updated_option', array('Pimex_Compare_Catalog', 'changed_option'), 10, 3);
        add_action('added_option', array('Pimex_Compare_Catalog', 'added_option'), 10, 2);
        add_action('wp_ajax_pimex_compare_prices', array(__CLASS__, 'prices'));
        add_action('wp_ajax_nopriv_pimex_compare_prices', array(__CLASS__, 'prices'));
        add_action('admin_bar_menu', function($bar) { if(current_user_can('manage_woocommerce')&&Pimex_Compare_SEO::is_page()) { $bar->add_node(array('id'=>'pimex-compare-version','title'=>'Porównywarka '.self::VERSION,'href'=>admin_url('admin.php?page=pimex-compare'))); } }, 100);
        Pimex_Compare_Admin::boot();
        Pimex_Compare_SEO::boot();
    }
    public static function builtin_filters() {
        return array('brand'=>'Producent','shade'=>'Kolor','material'=>'Materiał','construction'=>'Konstrukcja','coating'=>'Powłoka','surface'=>'Powierzchnia','width'=>'Szerokość','length'=>'Długość','thickness'=>'Grubość','price_mb'=>'Cena za mb','price_m2'=>'Cena za m²');
    }
    public static function builtin_table() {
        return array('price'=>'Cena za sztukę','rate_mb'=>'Cena za mb','rate_m2'=>'Cena za m²','area_basis'=>'Podstawa ceny za m²','application'=>'Zastosowanie','material'=>'Materiał','construction'=>'Konstrukcja','coating'=>'Powłoka','surface'=>'Powierzchnia','thickness'=>'Grubość','width'=>'Szerokość','length'=>'Długość','custom'=>'Produkcja na wymiar');
    }
    public static function attribute_definitions() {
        $out=array();
        if(function_exists('wc_get_attribute_taxonomies')){foreach((array)wc_get_attribute_taxonomies() as $attribute){
            if(empty($attribute->attribute_name)){continue;}
            $slug=sanitize_title($attribute->attribute_name);
            $out['attr_pa_'.$slug]=wp_strip_all_tags($attribute->attribute_label?:$attribute->attribute_name);
        }}
        return $out;
    }
    public static function definitions($kind) {
        $out=$kind==='table'?self::builtin_table():self::builtin_filters();
        foreach(self::attribute_definitions() as $field=>$label){$out[$field]=$label.(in_array($label,$out,true)?' (atrybut WooCommerce)':'');}
        return $out;
    }
    public static function filter_definitions() { return self::definitions('filter'); }
    public static function sanitize_fields($values,$kind,$append=false) {
        $definitions=self::definitions($kind);$out=array();
        foreach(is_array($values)?$values:array() as $field){if(is_string($field)&&isset($definitions[$field])&&!in_array($field,$out,true)){$out[]=$field;}}
        return $append?array_merge($out,array_values(array_diff(array_keys($definitions),$out))):$out;
    }
    public static function sanitize_filter_order($order) { return self::sanitize_fields($order,'filter',true); }
    public static function ordered_definitions($kind,$enabled_only=true) {
        $definitions=self::definitions($kind);$o=self::options();$out=array();
        foreach(self::sanitize_fields($o[$kind.'_order'],$kind,true) as $field){
            if(!$enabled_only||in_array($field,(array)$o[$kind.'_enabled'],true)){$out[$field]=$definitions[$field];}
        }
        return $out;
    }
    public static function ordered_filters() { return self::ordered_definitions('filter'); }
    public static function options() {
        return wp_parse_args((array)get_option(self::OPTION,array()),array('categories'=>array('deski-kompozytowe','deski-drewniane','kompozytowe-elewacje','lamele-kompozytowe'),'page'=>0,'filter_order'=>array_keys(self::builtin_filters()),'filter_enabled'=>array_keys(self::builtin_filters()),'table_order'=>array_keys(self::builtin_table()),'table_enabled'=>array_keys(self::builtin_table())));
    }
    public static function assets() {
        $post = get_post();
        if ($post && (has_shortcode($post->post_content, 'pimex_porownaj') || (int) $post->ID === (int) self::options()['page'])) { self::enqueue(); }
    }
    private static function enqueue() {
        wp_enqueue_script('pimex-compare-142', plugins_url('assets/app-1.4.2.min.js', __FILE__), array(), self::VERSION, true);
    }
    public static function styles() {
        static $css = null;
        if ($css === null) { $css = file_get_contents(__DIR__.'/assets/app-1.4.2.min.css'); }
        return '<style>'.$css.'</style>';
    }
    public static function shortcode() {
        self::enqueue();
        $snapshot = Pimex_Compare_Catalog::snapshot();
        $config = array('items'=>Pimex_Compare_Catalog::browser_items($snapshot['items'] ?? array()), 'limit'=>6, 'pageRows'=>4,
            'priceUrl'=>wp_make_link_relative(admin_url('admin-ajax.php')), 'tableFields'=>array_map(function($field,$label){return array($field,$label);},array_keys(self::ordered_definitions('table')),array_values(self::ordered_definitions('table'))), 'storage'=>'pimex-compare:'.get_current_blog_id());
        ob_start(); include __DIR__.'/templates/compare.php'; return ob_get_clean();
    }
    /** Public read-only, bounded endpoint. No mutations, cart or client-supplied prices. */
    public static function prices() {
        $raw = isset($_POST['ids']) && is_string($_POST['ids']) ? wp_unslash($_POST['ids']) : '';
        if (strlen($raw) > 800) { wp_send_json_error(array('message'=>'Za dużo produktów.'), 400); }
        $ids = array_values(array_unique(wp_parse_id_list($raw)));
        if (count($ids) > 24) { wp_send_json_error(array('message'=>'Za dużo produktów.'), 400); }
        $result = array();$groups=array();$budget=120;
        foreach(Pimex_Compare_Catalog::snapshot()['items']??array() as $item){foreach($item['aliases']??array($item['id']) as $member){$groups[(int)$member]=$item;}}
        foreach ($ids as $id) {
            $members=$groups[$id]['aliases']??array($id);
            if(count($members)>24||count($members)>$budget){$result[(string)$id]=array('price'=>'Sprawdź ceny na karcie produktu','stock'=>'unknown','stock_label'=>'Sprawdź dostępność na karcie produktu','purchasable'=>false);continue;}
            $budget-=count($members);$products=array();
            foreach($members as $member){$p=wc_get_product($member);if($p&&Pimex_Compare_Catalog::allowed($p)){$products[]=$p;}}
            if(!$products){continue;}
            $product=$products[0];$html=$product->get_price_html();$stocks=array();$purchasable=false;
            foreach($products as $p){$stocks[]=$p->get_stock_status();$purchasable=$purchasable||$p->is_purchasable();}
            if(count($products)>1){
                $prices=array();foreach($products as $p){if($p->get_price()!==''){$prices[]=(float)wc_get_price_to_display($p);}}
                if(count($prices)!==count($products)){$html='Sprawdź ceny na karcie produktu';}
                else{$min=min($prices);$max=max($prices);$html=($min===$max?wc_price($min):wc_format_price_range($min,$max)).$product->get_price_suffix();$html=apply_filters('woocommerce_get_price_html',$html,$product);}
            }
            $html = preg_replace('/<del\b[^>]*>.*?<\/del>/is', '', $html);
            $html = preg_replace('/<span\b[^>]*class=[\"\'][^\"\']*screen-reader-text[^\"\']*[\"\'][^>]*>.*?<\/span>/is', '', $html);
            $stock=in_array('instock',$stocks,true)?'instock':(in_array('onbackorder',$stocks,true)?'onbackorder':'outofstock');
            $result[(string) $id] = array('price'=>trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES, 'UTF-8'))),
                'stock'=>$stock,'stock_label'=>count(array_unique($stocks))>1?'Dostępność zależy od długości':'','purchasable'=>$purchasable)+Pimex_Compare_Rates::summarize($products);
        }
        nocache_headers(); wp_send_json_success($result);
    }
}
add_action('plugins_loaded', array('Pimex_Compare', 'boot'));
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('pimex_compare_build');
    delete_option(Pimex_Compare_Catalog::BUILD);
    delete_option('pimex_compare_lock');
});
