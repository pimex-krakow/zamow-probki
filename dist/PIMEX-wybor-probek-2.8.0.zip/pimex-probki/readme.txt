=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.8.0
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.8.0 =
Spójny wielokrotny wybór checkboxami we wszystkich filtrach.
Nowe filtry Powierzchnia i Materiał odczytują atrybuty produktów i wariantów.
Podsumowanie zawsze rozwinięte, na telefonie pod próbkami w zwykłym układzie strony.
Przycisk Zamów próbkę po prawej stronie Dodaj do koszyka, biały z zieloną ramką.
Szczegóły testów: AKTUALIZACJA-2.8.0.txt.
