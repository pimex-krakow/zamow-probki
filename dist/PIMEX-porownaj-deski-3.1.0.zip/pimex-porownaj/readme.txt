=== PIMEX — porównaj deski ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 3.1.0
License: GPLv2 or later

== Description ==
Dwie osobne strony: porównanie desek i zamawianie próbek. Wspólny wygląd
oraz rodzaje filtrów, niezależny wybór filtrów i ich kolejności w WooCommerce.
Porównanie ma osobny wybór wierszy tabeli, próbki własną dostępność.

== Installation ==
Zaktualizuj obie paczki: Porównaj deski 3.1.0 oraz Wybór próbek 4.0.0.
Instrukcja krok po kroku: START-TUTAJ.txt. Przy przejściu z 3.0.0 katalog nie wymaga przebudowy.
Zachowaj dwie strony: [pimex_porownaj] oraz [pimex_probki].

== Changelog ==
= 3.1.0 =
Pokaż tylko różnice z zachowaniem cen i brakujących danych. Kompaktowy nagłówek
podczas przewijania tabeli. Wybrane miniatury nad katalogiem. Objaśnienia parametrów.
Informacja o kolorach na stronie próbek. Moduł próbek 4.0.0 pozostaje zgodny.

= 3.0.0 =
Osobne widoki i ustawienia, wspólny interfejs. Przygotowany katalog,
odczyty porcjami i ładowanie zasobów selektora tylko na stronach narzędzi.
Szczegóły i ograniczenia testów: INSTRUKCJA.txt oraz TESTY.txt.
