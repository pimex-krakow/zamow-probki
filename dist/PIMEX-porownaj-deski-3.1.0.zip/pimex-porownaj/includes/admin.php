<?php
defined('ABSPATH') || exit;
final class Pimex_Compare_Admin {
    public static function boot(){
        add_action('admin_menu',function(){add_submenu_page('woocommerce','Porównaj deski PIMEX','Porównaj deski','manage_woocommerce','pimex-compare',array(__CLASS__,'render'));});
        add_action('admin_post_pimex_compare_setup',array(__CLASS__,'save'));
        add_action('wp_ajax_pimex_compare_build_admin',array(__CLASS__,'build'));
    }
    public static function save(){
        if(!current_user_can('manage_woocommerce')){wp_die('Brak uprawnień.');}check_admin_referer('pimex_compare_setup');
        $o=Pimex_Compare::options();$slugs=array();
        foreach((array)($_POST['categories']??array()) as $slug){if(!is_string($slug)){continue;}$slug=sanitize_title(wp_unslash($slug));if(get_term_by('slug',$slug,'product_cat')){$slugs[]=$slug;}}
        if(!$slugs){wp_die('Wybierz przynajmniej jedną kategorię produktów.');}$o['categories']=array_values(array_unique($slugs));
        foreach(array('filter','table') as $kind){
            if(isset($_POST[$kind.'_order'])){
                $raw=$_POST[$kind.'_order'];
                if(!is_string($raw)||strlen($raw)>65536){wp_die('Nieprawidłowa kolejność atrybutów.');}
                $order=json_decode(wp_unslash($raw),true);
                if(!is_array($order)){wp_die('Nieprawidłowa kolejność atrybutów.');}
                $o[$kind.'_order']=Pimex_Compare::sanitize_fields($order,$kind,true);
            }
            if(!empty($_POST['settings_lists'])){
                $o[$kind.'_enabled']=Pimex_Compare::sanitize_fields(wp_unslash((array)($_POST[$kind.'_enabled']??array())),$kind);
            }
        }
        if(!empty($_POST['create_page'])&&(!$o['page']||get_post_status($o['page'])==='trash'||!get_post_status($o['page']))){
            $id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_title'=>'Dobierz i porównaj deski','post_name'=>'dobierz-i-porownaj-deski','post_content'=>'[pimex_porownaj]'),true);
            if(is_wp_error($id)){wp_die('Nie udało się utworzyć strony.');}$o['page']=$id;
        }
        update_option(Pimex_Compare::OPTION,$o,false);
        wp_safe_redirect(admin_url('admin.php?page=pimex-compare&saved=1'));exit;
    }
    public static function build(){
        if(!current_user_can('manage_woocommerce')){wp_send_json_error(array('message'=>'Brak uprawnień.'),403);}
        check_ajax_referer('pimex_compare_build','nonce');
        $state=!empty($_POST['restart'])?Pimex_Compare_Catalog::start():Pimex_Compare_Catalog::batch();
        if(isset($state['error'])){wp_send_json_error(array('message'=>$state['error']),500);}wp_send_json_success($state);
    }
    public static function order_script(){
        echo <<<'JS'
        document.querySelectorAll('.pimex-settings-order').forEach(function(list){const value=document.getElementById(list.id+'-value');let dragged=null;
        const sync=()=>{const rows=[...list.children];value.value=JSON.stringify(rows.map(row=>row.dataset.field));rows.forEach((row,i)=>{row.querySelector('[data-order=up]').disabled=i===0;row.querySelector('[data-order=down]').disabled=i===rows.length-1;});};
        list.addEventListener('click',event=>{const button=event.target.closest('[data-order]');if(!button)return;const row=button.closest('[data-field]');if(button.dataset.order==='up'&&row.previousElementSibling)list.insertBefore(row,row.previousElementSibling);else if(button.dataset.order==='down'&&row.nextElementSibling)list.insertBefore(row.nextElementSibling,row);sync();button.focus();});
        list.addEventListener('dragstart',event=>{dragged=event.target.closest('[data-field]');if(dragged){event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',dragged.dataset.field);}});
        list.addEventListener('dragover',event=>{if(!dragged)return;event.preventDefault();const row=event.target.closest('[data-field]');if(!row||row===dragged)return;const box=row.getBoundingClientRect();list.insertBefore(dragged,event.clientY<box.top+box.height/2?row:row.nextElementSibling);});
        list.addEventListener('dragend',()=>{dragged=null;sync();});list.closest('form').addEventListener('submit',sync);sync();});
JS;
    }
    public static function samples_filter_editor(){
        $o=Pimex_Compare::view_settings('samples'); ?>
        <h2>Filtry strony próbek — widoczność i kolejność</h2>
        <p>To te same rodzaje filtrów i styl co w porównywarce, z osobnym wyborem i kolejnością. Zaznacz widoczne pozycje, przestaw je i zapisz. Dostępność próbek wybierasz w tabeli poniżej.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="pimex_samples_filters"><?php wp_nonce_field('pimex_samples_filters'); ?>
        <ol id="pimex-samples-filter-order" class="pimex-settings-order" style="max-width:620px;margin-left:0;list-style:none">
        <?php foreach(Pimex_Compare::ordered_definitions('filter',false,'samples') as $field=>$label){ ?>
        <li draggable="true" data-field="<?php echo esc_attr($field); ?>" style="display:flex;align-items:center;gap:10px;padding:9px 12px;margin:0 0 6px;background:white;border:1px solid #ccc;border-radius:3px;cursor:grab">
        <span aria-hidden="true">☰</span><label style="flex:1"><input type="checkbox" name="view_filter_enabled[]" value="<?php echo esc_attr($field); ?>" <?php echo in_array($field,(array)$o['filter_enabled'],true)?'checked':''; ?>> <?php echo esc_html($label); ?></label>
        <button type="button" class="button" data-order="up" aria-label="<?php echo esc_attr('Przesuń '.$label.' w górę'); ?>">↑</button><button type="button" class="button" data-order="down" aria-label="<?php echo esc_attr('Przesuń '.$label.' w dół'); ?>">↓</button></li>
        <?php } ?></ol>
        <input type="hidden" id="pimex-samples-filter-order-value" name="view_filter_order" value="<?php echo esc_attr(wp_json_encode(array_keys(Pimex_Compare::ordered_definitions('filter',false,'samples')))); ?>">
        <?php submit_button('Zapisz filtry próbek'); ?></form><script><?php self::order_script(); ?></script>
        <?php
    }
    public static function render(){
        if(!current_user_can('manage_woocommerce')){return;}
        $o=Pimex_Compare::options();$snapshot=Pimex_Compare_Catalog::snapshot();$terms=get_terms(array('taxonomy'=>'product_cat','hide_empty'=>false));
        ?>
        <div class="wrap"><h1>Porównaj deski PIMEX</h1>
        <p>Osobna strona porównania desek. Tutaj wybierasz filtry oraz wiersze tabeli. Filtry i dostępne próbki dla drugiej strony ustawiasz w WooCommerce → Próbki PIMEX.</p>
        <?php if(Pimex_Compare_Samples::supported()){ $sampleOptions=Pimex_Samples_1::options(); ?>
        <p>Próbka: <strong><?php echo esc_html(number_format((float)$sampleOptions['price'],2,',',' ').' zł'); ?></strong>, wysyłka zestawu w Polsce: <strong><?php echo esc_html(number_format((float)$sampleOptions['shipping'],2,',',' ').' zł'); ?></strong>, limit: <?php echo esc_html($sampleOptions['max']); ?>. <a href="<?php echo esc_url(admin_url('admin.php?page=pimex-probki')); ?>">Ustawienia cen, dostępności i zamawiania próbek</a>.</p>
        <?php }else{ ?><p><strong>Aby zamawiać próbki, pozostaw aktywną aktualną wtyczkę PIMEX — wybór próbek (testowana wersja 4.0.0). Porównywanie działa także bez niej.</strong></p><?php } ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="pimex_compare_setup"><?php wp_nonce_field('pimex_compare_setup'); ?>
        <h2>1. Wybierz produkty i przygotuj stronę</h2>
        <p><label for="pimex-compare-categories">Kategorie desek i lameli (można zaznaczyć kilka, przytrzymując Ctrl lub Cmd):</label></p>
        <select id="pimex-compare-categories" name="categories[]" multiple size="9" required>
        <?php if(!is_wp_error($terms)){foreach($terms as $term){?><option value="<?php echo esc_attr($term->slug); ?>" <?php selected(in_array($term->slug,$o['categories'],true)); ?>><?php echo esc_html($term->name.' ('.$term->slug.')'); ?></option><?php }} ?>
        </select>
        <?php if(!$o['page']||!get_post_status($o['page'])||get_post_status($o['page'])==='trash'){?><p><label><input type="checkbox" name="create_page" value="1" checked> Utwórz szkic strony „Dobierz i porównaj deski”</label></p><?php } ?>
        <input type="hidden" name="settings_lists" value="1">
        <p>Atrybuty dodajesz w Produkty → Atrybuty, a ich wartości uzupełniasz w produktach. Nowe atrybuty są domyślnie wyłączone. Po dodaniu atrybutu lub jego wartości odśwież katalog.</p>
        <?php foreach(array('filter'=>'Filtry — widoczność i kolejność','table'=>'Tabela — widoczność i kolejność') as $kind=>$heading){ ?>
        <h2><?php echo esc_html($heading); ?></h2>
        <p>Zaznacz widoczne pozycje. Przeciągaj lub użyj strzałek, a następnie kliknij Zapisz ustawienia.<?php if($kind==='filter'){ ?> Rodzaje desek pozostają nad filtrami.<?php } ?></p>
        <ol id="pimex-<?php echo esc_attr($kind); ?>-order" class="pimex-settings-order" style="max-width:620px;margin-left:0;list-style:none">
        <?php foreach(Pimex_Compare::ordered_definitions($kind,false) as $field=>$label){ ?>
        <li draggable="true" data-field="<?php echo esc_attr($field); ?>" style="display:flex;align-items:center;gap:10px;padding:9px 12px;margin:0 0 6px;background:white;border:1px solid #ccc;border-radius:3px;cursor:grab">
        <span aria-hidden="true">☰</span><label style="flex:1"><input type="checkbox" name="<?php echo esc_attr($kind); ?>_enabled[]" value="<?php echo esc_attr($field); ?>" <?php echo in_array($field,(array)$o[$kind.'_enabled'],true)?'checked':''; ?>> <?php echo esc_html($label); ?></label>
        <button type="button" class="button" data-order="up" aria-label="<?php echo esc_attr('Przesuń '.$label.' w górę'); ?>">↑</button>
        <button type="button" class="button" data-order="down" aria-label="<?php echo esc_attr('Przesuń '.$label.' w dół'); ?>">↓</button>
        </li>
        <?php } ?>
        </ol>
        <input type="hidden" id="pimex-<?php echo esc_attr($kind); ?>-order-value" name="<?php echo esc_attr($kind); ?>_order" value="<?php echo esc_attr(wp_json_encode(array_keys(Pimex_Compare::ordered_definitions($kind,false)))); ?>">
        <?php } ?>
        <?php submit_button('Zapisz ustawienia'); ?>
        </form>
        <h2>2. Przygotuj katalog</h2>
        <?php if(empty($snapshot['master_schema'])){ ?><p><strong>Po aktualizacji 3.0 przygotuj katalog raz ponownie — wspólne dane obejmą wszystkie rodziny desek, także niewybrane do porównania.</strong></p><?php } ?>
        <?php if(!empty($snapshot['items'])&&empty($snapshot['attributes_schema'])){?><p><strong>Odśwież katalog po aktualizacji, aby wczytać dodatkowe atrybuty WooCommerce.</strong></p><?php } ?>
        <?php if(!empty($snapshot['items'])&&empty($snapshot['grouped'])){?><p><strong>Po aktualizacji przygotuj katalog ponownie, aby połączyć warianty długości i dodać wybór rodzaju desek.</strong></p><?php } ?>
        <p>Katalog jest przygotowywany partiami. Nie zamykaj tego panelu do zakończenia. Poprzedni katalog pozostaje widoczny podczas odświeżania.</p>
        <p>Produkty w katalogu: <strong><?php echo esc_html(count($snapshot['items']??array())); ?></strong>.
        <?php if(!empty($snapshot['built'])){echo ' Ostatnie przygotowanie: '.esc_html(wp_date('d.m.Y H:i',$snapshot['built']));} ?></p>
        <?php if(class_exists('Pimex_Samples_1')){?><p>Grupy kolorów są odczytywane z wtyczki „PIMEX — wybór próbek”, wraz z ręcznymi przypisaniami. Aktualizują się przy ponownym przygotowaniu katalogu.</p><?php }else{?><p>Wtyczka próbek nie jest aktywna. Stosowane są reguły rozpoznawania kolorów; Basalt i Antique pozostają nieprzypisane do grup.</p><?php } ?>
        <button type="button" class="button button-primary" id="pimex-compare-build">Przygotuj / odśwież katalog</button>
        <p id="pimex-compare-progress" role="status" aria-live="polite"></p>
        <h2>3. Sprawdź i opublikuj</h2>
        <?php if($o['page']&&get_post_status($o['page'])&&get_post_status($o['page'])!=='trash'){?><p><a class="button" href="<?php echo esc_url(get_edit_post_link($o['page'])); ?>">Edytuj / opublikuj stronę</a> <a class="button" href="<?php echo esc_url(get_preview_post_link($o['page'])); ?>">Podgląd strony</a></p><?php } ?>
        <p>Shortcode: <code>[pimex_porownaj]</code> lub <code>[pimex_dobierz_deski]</code>. Na osobnej stronie próbek pozostaw <code>[pimex_probki]</code>. Obie strony mają wspólny styl, ale oddzielne zadania i ustawienia.</p>
        <p>Strona wskazana w tym panelu jest oznaczona jako noindex i wyłączona z mapy stron WordPress / Yoast. Kategorie i produkty zachowują dotychczasowe ustawienia SEO.</p>
        <p>We wbudowanych ustawieniach strony WoodMart wybierz układ bez panelu bocznego, aby porównywarka wykorzystała szerokość treści.</p>
        <p>Ceny i dostępność są pobierane na bieżąco z WooCommerce dla widocznych produktów. Zdjęcia przedstawiają produkty sklepu. Zaznaczenie porównania ani próbki nie zmienia koszyka. Próbki trafiają do niego dopiero po kliknięciu Zamów próbki.</p>
        </div>
        <script>
        <?php self::order_script(); ?>
        (function(){const button=document.getElementById('pimex-compare-build'),status=document.getElementById('pimex-compare-progress');let active=false;
        button.addEventListener('click',async function(){if(active)return;active=true;button.disabled=true;let first=true;
        try{while(active){status.textContent='Przygotowywanie katalogu…';const data=new URLSearchParams({action:'pimex_compare_build_admin',nonce:<?php echo wp_json_encode(wp_create_nonce('pimex_compare_build')); ?>,restart:first?'1':''});
        const response=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:data});const result=await response.json();if(!response.ok||!result.success)throw new Error(result.data?.message||'Nie udało się przygotować katalogu.');
        const state=result.data;if(!state.busy)first=false;status.textContent=state.busy?'Katalog jest przygotowywany w tle. Czekam na zakończenie partii…':'Przetworzono '+state.processed+' produktów z '+state.total+'. Pozycje: '+state.items+'.';
        if(state.done){status.textContent='Gotowe. Katalog zawiera '+state.items+' modeli i kolorów. Możesz otworzyć podgląd strony.';break;}
        await new Promise(resolve=>setTimeout(resolve,state.busy?1800:150));}
        }catch(error){status.textContent='Nie udało się przygotować katalogu. Odśwież panel i spróbuj ponownie; poprzedni katalog pozostał dostępny.';}finally{active=false;button.disabled=false;}});})();
        </script>
        <?php
    }
}
