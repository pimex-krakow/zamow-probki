<?php
defined('ABSPATH') || exit;
final class Pimex_Compare_Catalog {
    const SNAPSHOT='pimex_compare_catalog_v1';
    const BUILD='pimex_compare_build_v1';
    const REVISION='pimex_compare_revision';
    private static $queued=false;
    public static function snapshot(){ $v=get_option(self::SNAPSHOT,array());return is_array($v)?$v:array(); }
    public static function schedule(){if(!self::$queued&&!wp_next_scheduled('pimex_compare_build')){self::$queued=(bool)wp_schedule_single_event(time()+10,'pimex_compare_build');}}
    public static function invalidate(){update_option(self::REVISION,microtime(true),false);if(self::snapshot()||get_option(self::BUILD,false)){self::schedule();}}
    public static function changed_product($id){if(get_post_meta($id,'_pimex_samples_owned',true)!=='yes'){self::invalidate();}}
    public static function changed_term($id,$tt,$taxonomy){if($taxonomy==='product_cat'||$taxonomy==='product_brand'||strpos($taxonomy,'pa_')===0){self::invalidate();}}
    public static function deleted_post($id,$post){if($post&&in_array($post->post_type,array('product','product_variation','attachment'),true)){self::invalidate();}}
    public static function changed_option($name,$old,$new){if(in_array($name,array('pimex_samples_shades','pimex_samples_1',Pimex_Compare::OPTION),true)&&$old!==$new){self::invalidate();}}
    public static function added_option($name,$value){self::changed_option($name,null,$value);}
    public static function parent($p){return $p->is_type('variation')?wc_get_product($p->get_parent_id()):$p;}
    public static function allowed($p) {
        if(!$p||$p->get_status()!=='publish'){return false;}
        $parent=self::parent($p);
        if(!$parent||$parent->get_status()!=='publish'||$parent->get_catalog_visibility()==='hidden'||$parent->get_meta('_pimex_samples_owned')==='yes'){return false;}
        if(!in_array($p->get_type(),array('simple','variable','variation'),true)){return false;}
        $excluded=array('legary','legary-tarasowe','wsporniki-tarasowe','elementy-montazowe','elementy-wykonczeniowe','klipsy','listwy-wykonczeniowe','elementy-montazowe-deski-elewacyjne','elementy-wykonczeniowe-deski-elewacyjne');
        $slugs=self::category_slugs($parent);
        return (bool)array_intersect($slugs,Pimex_Compare::options()['categories'])&&!array_intersect($slugs,$excluded);
    }
    private static function category_slugs($p){
        $slugs=array();foreach($p->get_category_ids() as $id){foreach(array_merge(array($id),get_ancestors($id,'product_cat','taxonomy')) as $tid){$term=get_term($tid,'product_cat');if($term&&!is_wp_error($term)){$slugs[]=$term->slug;}}}return array_unique($slugs);
    }
    private static function category($slugs) {
        $out=array();
        if(array_intersect($slugs,array('deski-tarasowe','deski-kompozytowe','deski-drewniane'))){$out[]='Deski tarasowe';}
        if(array_intersect($slugs,array('deski-elewacyjne','kompozytowe-elewacje'))){$out[]='Deski elewacyjne';}
        if(in_array('lamele-kompozytowe',$slugs,true)){$out[]='Lamele elewacyjne';}
        return $out;
    }
    private static function length_profile($p,$parent) {
        $profile=array();
        if($p->is_type('variation')){foreach($p->get_attributes() as $name=>$value){
            $key=preg_replace('/^pa-/', '', sanitize_title(str_replace('_','-',$name)));
            $label=sanitize_title(wc_attribute_label($name,$parent));
            if(preg_match('/^dlugosc(?:-(?:mm|cm|m|deski))?$/',$key)||preg_match('/^dlugosc(?:-(?:mm|cm|m|deski))?$/',$label)){continue;}
            $profile[$key]=(string)$value;
        }}
        ksort($profile);return $parent->get_id().':'.md5(wp_json_encode($profile));
    }
    /** Only sibling variants differing in length; other dimensions, color and profiles stay distinct. */
    public static function groups($items) {
        usort($items,function($a,$b){return (int)$a['id']<=>(int)$b['id'];});$out=array();
        foreach($items as $item){
            // Legacy snapshots lack the complete variation profile. Rebuild in admin before grouping.
            $key=$item['length_profile']??('legacy:'.$item['id']);
            $ids=array_values(array_unique(array_map('intval',$item['aliases']??array($item['id']))));
            if(!isset($out[$key])){$item['aliases']=$ids;$out[$key]=$item;continue;}
            $a=&$out[$key];
            $a['aliases']=array_values(array_unique(array_merge($a['aliases'],$ids)));sort($a['aliases'],SORT_NUMERIC);
            $a['length']=array_values(array_unique(array_merge($a['length'],$item['length'])));sort($a['length'],SORT_NUMERIC);
            $a['custom']=!empty($a['custom'])||!empty($item['custom']);
            foreach(array('shades','application','category') as $field){$a[$field]=array_values(array_unique(array_merge($a[$field]??array(),$item[$field]??array())));}
            $a['sku']=implode(' / ',array_values(array_unique(array_filter(array_merge(explode(' / ',$a['sku']),explode(' / ',$item['sku']))))));
            if(empty($a['sample_url'])&&!empty($item['sample_url'])){$a['sample_url']=$item['sample_url'];}
            unset($a);
        }
        return array_values($out);
    }
    public static function browser_items($items) {
        return array_map(function($item){unset($item['length_profile'],$item['parent']);return $item;},$items);
    }
    public static function describe($p,$parent) {
        $a='Pimex_Compare_Attributes';
        $brand=$a::field($p,$parent,array('producent','producent-marka','marka'));
        if(!$brand&&taxonomy_exists('product_brand')){$terms=get_the_terms($parent->get_id(),'product_brand');if($terms&&!is_wp_error($terms)){$brand=wp_list_pluck($terms,'name');}}
        if(!$brand){foreach($parent->get_category_ids() as $id){foreach(get_ancestors($id,'product_cat','taxonomy') as $ancestor){$term=get_term($ancestor,'product_cat');if($term&&!is_wp_error($term)&&$term->slug==='producenci'){$leaf=get_term($id,'product_cat');if($leaf&&!is_wp_error($leaf)){$brand=array($leaf->name);break 2;}}}}}
        $color=implode(', ',$a::field($p,$parent,array('kolor','color')));
        $shades=$a::color_groups($color);$sample_url='';
        // Read-only bridge, only during catalog preparation. Never shares the samples cache or edits products.
        if(class_exists('Pimex_Samples_1')&&class_exists('Pimex_Samples_Catalog')&&method_exists('Pimex_Samples_1','source')){
            $sample=Pimex_Samples_1::source($p->get_id(),true);
            if($sample){$shades=(array)$sample['shades'];$o=Pimex_Samples_1::options();if(!empty($sample['available'])&&!empty($o['page'])&&get_post_status($o['page'])==='publish'){$sample_url=add_query_arg('pimex_pick',$p->get_id(),get_permalink($o['page']));}}
        }
        $slugs=self::category_slugs($parent);$category=self::category($slugs);$group=in_array('Lamele elewacyjne',$category,true)?'Lamele elewacyjne':(in_array('Deski elewacyjne',$category,true)?'Deski elewacyjne':'Deski tarasowe');
        $image=$p->get_image_id()?:$parent->get_image_id();
        $item=array('id'=>$p->get_id(),'parent'=>$parent->get_id(),'name'=>$parent->get_name(),
            'title'=>implode(' / ',$a::field($p,$parent,array('seria-system','seria','kolekcja')))?:$parent->get_name(),
            'brand'=>implode(' / ',$brand)?:'Pozostałe','type'=>implode(' / ',$a::field($p,$parent,array('typ-elementu'))),
            'length_profile'=>self::length_profile($p,$parent),'category'=>$category,
            'color'=>$color,'shades'=>$shades,'application'=>$a::field($p,$parent,array('zastosowanie'))?:array($group),
            'material'=>$a::field($p,$parent,array('material')),'construction'=>$a::field($p,$parent,array('konstrukcja')),
            'coating'=>$a::field($p,$parent,array('powloka')),'surface'=>$a::field($p,$parent,array('powierzchnia')),
            'width'=>$a::dimensions($p,$parent,'szerokosc'),'length'=>$a::dimensions($p,$parent,'dlugosc'),
            'thickness'=>$a::dimensions($p,$parent,'grubosc'),'custom'=>$a::custom($p,$parent),
            'image'=>($image?wp_get_attachment_image_url($image,'woocommerce_thumbnail'):wc_placeholder_img_src())?:wc_placeholder_img_src(),
            'url'=>$parent->get_permalink(),'sample_url'=>$sample_url,'sku'=>$p->get_sku());
        return $item;
    }
    public static function start(){
        // Keep the existing catalog while building its replacement.
        return self::batch(true);
    }
    public static function batch($restart=false){
        $lock='pimex_compare_lock';$previous=get_option($lock,'');
        if($previous&&(int)$previous<time()-180){delete_option($lock);}
        $token=time().':'.uniqid('',true);
        if(!add_option($lock,$token,'',false)){self::schedule();return array('busy'=>true,'done'=>false);}
        try{
            if($restart){update_option(self::REVISION,microtime(true),false);}
            $build=$restart?array():get_option(self::BUILD,array());
            if(!$build){$build=array('page'=>1,'items'=>array(),'processed'=>0,'revision'=>get_option(self::REVISION,'0'),'locale'=>get_locale());}
            $query=new WP_Query(array('post_type'=>'product','post_status'=>'publish','fields'=>'ids','posts_per_page'=>20,'paged'=>$build['page'],'orderby'=>'ID','order'=>'ASC','no_found_rows'=>false,
                'tax_query'=>array(array('taxonomy'=>'product_cat','field'=>'slug','terms'=>Pimex_Compare::options()['categories'],'include_children'=>true))));
            if(function_exists('_prime_post_caches')){_prime_post_caches($query->posts,true,true);}
            foreach($query->posts as $id){
                $parent=wc_get_product($id);if(!self::allowed($parent)){continue;}
                $ids=$parent->is_type('variable')?$parent->get_children():array($id);
                if(function_exists('_prime_post_caches')){_prime_post_caches($ids,true,true);}
                foreach($ids as $product_id){$p=wc_get_product($product_id);if(self::allowed($p)){$build['items'][(string)$product_id]=self::describe($p,$parent);}}
            }
            $build['processed']+=count($query->posts);$done=$build['page']>=max(1,(int)$query->max_num_pages);
            if($done){
                $items=self::groups(array_values($build['items']));usort($items,function($a,$b){return strnatcasecmp($a['brand'].' '.$a['title'].' '.$a['color'],$b['brand'].' '.$b['title'].' '.$b['color']);});
                update_option(self::SNAPSHOT,array('grouped'=>true,'items'=>$items,'revision'=>$build['revision'],'built'=>time(),'locale'=>$build['locale']),false);
                delete_option(self::BUILD);wp_clear_scheduled_hook('pimex_compare_build');self::$queued=false;
                if((string)$build['revision']!==(string)get_option(self::REVISION,'0')){self::schedule();}
            }else{$build['page']++;update_option(self::BUILD,$build,false);self::schedule();}
            return array('done'=>$done,'processed'=>$build['processed'],'items'=>$done?count($items):count($build['items']),'total'=>(int)$query->found_posts);
        }catch(Throwable $e){
            if(function_exists('wc_get_logger')){wc_get_logger()->error($e->getMessage(),array('source'=>'pimex-compare'));}
            return array('error'=>'Nie udało się przygotować katalogu. Spróbuj ponownie; poprzedni katalog pozostał dostępny.');
        }finally{if(get_option($lock,'')===$token){delete_option($lock);}}
    }
}
