=== PIMEX — wybór próbek ===
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 2.5.1
License: GPLv2 or later

Wybór próbek desek i lameli z istniejących produktów WooCommerce.
Cena próbki 4 zł brutto, wysyłka zestawu w Polsce 14 zł brutto.

== Installation ==
Instrukcja instalacji, aktualizacji i testu zakupowego: INSTRUKCJA.txt.

== Changelog ==
= 2.5.1 =
* Wygląd oparty na globalnych stylach motywu i przyciskach WooCommerce.
* Lokalny plik CSS wyłącznie dla struktury, bez osobnej palety i fontów.
* Instrukcja instalacji od początku i podpięcia istniejącego przycisku.
= 2.0.0 =
* Przebudowana strona wyboru z podziałem na zastosowanie i filtrami producenta/koloru.
* Wyszukiwanie nazw, SKU i polskich znaków.
* Pusty początkowy zestaw i preselektowanie po wejściu z produktu.
* Rozwijane podsumowanie na telefonie, czytelne zaznaczenia i usuwanie pozycji.
* Panel dostępności próbek z miniaturami i wyszukiwaniem.
* Dodanie pozycji do wybranego menu bez przestawiania dotychczasowych pozycji.
* Kafelek strony głównej [pimex_probki_kafelek].
* Deduplikacja wariantów długości i kompletnie opisanych produktów tego samego profilu.
* Buforowanie katalogu i automatyczne unieważnianie po zmianach produktów.
* Serwerowa walidacja próbek, stałej ceny, limitu i danych zamówienia.
* Zachowanie ustawień, produktu technicznego i strony z wersji 1.0.
= 1.0.0 =
* Pierwsza wersja wyboru próbek.
