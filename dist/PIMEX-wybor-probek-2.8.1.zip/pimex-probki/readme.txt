=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.8.1
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.8.1 =
Adres produktu technicznego przekierowuje 301 na opublikowaną stronę próbek.
Produkt wykluczony z indeksowania i map witryny WordPressa oraz Yoast SEO.
Obsługa koszyka i zamówień pozostaje oparta na istniejącym produkcie.
Szczegóły testów: AKTUALIZACJA-2.8.1.txt.
