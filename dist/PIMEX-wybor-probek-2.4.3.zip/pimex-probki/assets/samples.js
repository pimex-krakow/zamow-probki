(function () {
    'use strict';
    function initialize() {
        document.querySelectorAll('.pimex-samples.ps-v2').forEach(function (root) {
            if (root.dataset.bound === 'yes' || !window.PimexSampleSelection) return;
            root.dataset.bound = 'yes';
            let cfg;
            try { cfg = JSON.parse(root.dataset.config); } catch (_) { return; }
            const model = new window.PimexSampleSelection.Selection(cfg.items, cfg.max);
            const grid = root.querySelector('.ps-grid'), list = root.querySelector('.ps-selected');
            const search = root.querySelector('.ps-search'), brand = root.querySelector('.ps-brand'), color = root.querySelector('.ps-color-filter');
            const ids = root.querySelector('.ps-ids'), submit = root.querySelector('.ps-submit'), feedback = root.querySelector('.ps-feedback');
            const details = root.querySelector('.ps-details'), pager = root.querySelector('.ps-pagination');
            const filters = { group: '', brand: '', color: '', search: '', construction: '', coating: '', width: null, length: null, thickness: null };
            const dimensionResets = [];
            const small = window.matchMedia('(max-width: 767px)');
            let page = 1;
            const money = value => value.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' zł';
            const element = (tag, className, text) => {
                const node = document.createElement(tag);
                if (className) node.className = className;
                if (text !== undefined) node.textContent = text;
                return node;
            };
            const shortName = item => (item.title || item.label) + (item.color ? ' — ' + item.color : '');
            const axisTitle = axis => ({width:'Szerokość deski', length:'Długość deski', thickness:'Grubość deski'})[axis];
            const axisEmpty = axis => ({width:'Wszystkie szerokości', length:'Wszystkie długości', thickness:'Wszystkie grubości'})[axis];
            function readSaved() {
                try { model.restore(JSON.parse(localStorage.getItem(cfg.storage) || '[]')); } catch (_) {}
            }
            function persist() {
                try { localStorage.setItem(cfg.storage, JSON.stringify(Array.from(model.selected))); } catch (_) {}
            }
            function notify(text) { feedback.textContent = text; }
            function updateSelection() {
                const totals = model.totals();
                list.replaceChildren();
                model.entries().forEach(function (item) {
                    const li = element('li'), image = element('img'), info = element('span', 'ps-selected-info');
                    image.src = item.image_url; image.alt = ''; image.loading = 'lazy';
                    info.append(element('strong', '', item.color || item.title), element('span', '', item.color ? item.title : item.brand));
                    const remove = element('button', 'button ps-remove', '×');
                    remove.type = 'button'; remove.setAttribute('aria-label', 'Usuń próbkę: ' + shortName(item));
                    remove.addEventListener('click', function () { model.choose(item.key, false); persist(); updateSelection(); notify('Usunięto próbkę: ' + shortName(item)); });
                    li.append(image, info, remove); list.append(li);
                });
                root.querySelector('.ps-count').textContent = String(totals.count);
                const n = totals.count;
                root.querySelector('.ps-mobile-unit').textContent = n === 1 ? 'próbka' : (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 'próbki' : 'próbek');
                root.querySelector('.ps-quantity-label').textContent = 'Próbki · ' + totals.count + ' szt.';
                root.querySelector('.ps-subtotal').textContent = money(totals.subtotal);
                root.querySelector('.ps-shipping').textContent = totals.count ? money(totals.shipping) : '—';
                root.querySelector('.ps-grand-total').textContent = money(totals.total);
                root.querySelector('.ps-mobile-total').textContent = money(totals.total);
                root.querySelector('.ps-empty-selection').hidden = totals.count > 0;
                root.querySelector('.ps-clear').disabled = totals.count === 0;
                submit.disabled = !cfg.enabled || totals.count === 0;
                ids.value = JSON.stringify(model.ids());
                grid.querySelectorAll('.ps-check').forEach(function (check) {
                    const on = model.selected.has(check.dataset.key);
                    check.checked = on;
                    const card = check.closest('.ps-card');
                    card.classList.toggle('is-selected', on);
                    card.querySelector('.ps-picked').hidden = !on;
                });
            }
            function setOptions(select, values, placeholder, selected) {
                const unique = Array.from(new Set(values.filter(Boolean))).sort((a, b) => a.localeCompare(b, 'pl'));
                select.replaceChildren();
                const first = element('option', '', placeholder); first.value = ''; select.append(first);
                unique.forEach(value => { const option = element('option', '', value); option.value = value; select.append(option); });
                select.value = unique.includes(selected) ? selected : '';
                return select.value;
            }
            function facets() {
                const base = model.filter({ group: filters.group, search: filters.search });
                filters.brand = setOptions(brand, base.map(item => item.brand), 'Wszyscy producenci', filters.brand);
                color.value = filters.color;
            }
            function changeChoice(item, check) {
                const outcome = model.choose(item.key, check.checked);
                if (!outcome.ok) {
                    check.checked = false;
                    notify('Możesz wybrać maksymalnie ' + cfg.max + ' różnych próbek. Usuń jedną z zestawu, aby wybrać kolejną.');
                    if (small.matches) details.open = true;
                    return;
                }
                persist(); updateSelection();
                notify(check.checked ? 'Dodano próbkę: ' + shortName(item) : 'Usunięto próbkę: ' + shortName(item));
            }
            function productCard(item) {
                const article = element('article', 'ps-card'), label = element('label', 'ps-choice');
                const check = element('input', 'ps-check'); check.type = 'checkbox'; check.dataset.key = item.key;
                check.disabled = !cfg.enabled; check.setAttribute('aria-label', 'Wybierz próbkę: ' + shortName(item));
                check.addEventListener('change', () => changeChoice(item, check));
                const frame = element('span', 'ps-image'), image = element('img');
                image.src = item.image_url; image.alt = item.product_title || item.title || item.label; image.loading = 'lazy'; image.decoding = 'async';
                frame.append(image);
                const picked = element('span', 'ps-picked', '✓ Wybrano'); picked.hidden = true;
                label.append(check, frame, picked);
                const link = element('a', 'ps-title ps-product-title', item.product_title || item.title || item.label);
                link.href = item.url; link.target = '_blank'; link.rel = 'noopener';
                article.append(label, link); return article;
            }
            function renderPager(total) {
                pager.replaceChildren();
                if (total <= 1) return;
                function pageButton(number, text, disabled) {
                    const button = element('button', 'button', text); button.type = 'button'; button.disabled = disabled;
                    if (number === page && !disabled) button.setAttribute('aria-current', 'page');
                    button.addEventListener('click', () => { page = number; renderProducts(); root.querySelector('.ps-result-line').scrollIntoView({ block: 'start', behavior: 'auto' }); });
                    pager.append(button);
                }
                pageButton(page - 1, '← Poprzednia', page === 1);
                const visible = new Set([1, total, page - 1, page, page + 1]);
                let previous = 0;
                Array.from(visible).filter(n => n > 0 && n <= total).sort((a, b) => a - b).forEach(n => {
                    if (previous && n - previous > 1) pager.append(element('span', '', '…'));
                    pageButton(n, String(n), false); previous = n;
                });
                pageButton(page + 1, 'Następna →', page === total);
            }
            function renderActiveFilters() {
                const box = root.querySelector('.ps-active-filters');
                box.replaceChildren();
                function chip(name, label, clear) {
                    const button = element('button', 'button ps-filter-chip', label + ' ×');
                    button.type = 'button'; button.dataset.filter = name;
                    button.setAttribute('aria-label', 'Usuń filtr: ' + label);
                    button.addEventListener('click', () => { clear(); page = 1; facets(); renderProducts(); });
                    box.append(button);
                }
                if (filters.group) {
                    const labels = {tarasy:'Deski tarasowe', elewacje:'Deski elewacyjne', lamele:'Lamele elewacyjne'};
                    chip('group', labels[filters.group], () => { filters.group = ''; });
                }
                if (filters.search.trim()) chip('search', 'Szukaj: ' + filters.search.trim(), () => { clearTimeout(searchTimer); filters.search = ''; search.value = ''; });
                ['brand','color','construction','coating'].forEach(name => {
                    if (!filters[name]) return;
                    const select = name === 'brand' ? brand : (name === 'color' ? color : root.querySelector('.ps-' + name));
                    const labels = {brand:'Producent', color:'Kolor', construction:'Konstrukcja', coating:'Powłoka'};
                    const option = Array.from(select.options).find(option => option.value === filters[name]);
                    chip(name, labels[name] + ': ' + (option ? option.textContent : filters[name]), () => { filters[name] = ''; select.value = ''; });
                });
                ['width','length','thickness'].forEach(axis => {
                    (filters[axis] || []).forEach(value => {
                        const check = Array.from(root.querySelectorAll('[data-axis="' + axis + '"] input')).find(input => input.value === String(value));
                        const label = (axisTitle(axis).replace(' deski', '') + ': ') + (check ? check.dataset.label : value);
                        chip(axis, label, () => { if (check) { check.checked = false; check.dispatchEvent(new Event('change')); } });
                    });
                });
                box.hidden = !box.childElementCount;
                const extra = Number(Boolean(filters.construction)) + Number(Boolean(filters.coating)) + (filters.width || []).length + (filters.length || []).length + (filters.thickness || []).length;
                root.querySelector('.ps-more-count').textContent = extra ? ' (' + extra + ')' : '';
            }
            function renderProducts() {
                const matching = model.filter(filters), size = Number(cfg.pageSize) || 18;
                const pages = Math.max(1, Math.ceil(matching.length / size)); page = Math.min(page, pages);
                grid.replaceChildren();
                matching.slice((page - 1) * size, page * size).forEach(item => grid.append(productCard(item)));
                root.querySelector('.ps-results').textContent = matching.length ? 'Dostępne próbki: ' + matching.length : 'Brak wyników';
                root.querySelector('.ps-empty').hidden = matching.length > 0;
                root.querySelectorAll('.ps-groups button').forEach(button => {
                    button.setAttribute('aria-pressed', String(button.dataset.group === filters.group));
                    button.querySelector('span').textContent = String(model.filter({ group: button.dataset.group }).length);
                });
                renderPager(pages); renderActiveFilters(); updateSelection();
            }
            function resetFilters() {
                filters.group = ''; filters.search = ''; filters.brand = ''; filters.color = ''; filters.construction = ''; filters.coating = ''; filters.width = null; filters.length = null; filters.thickness = null;
                root.querySelector('.ps-construction').value = ''; root.querySelector('.ps-coating').value = '';
                dimensionResets.forEach(reset => reset()); search.value = ''; page = 1; facets(); renderProducts();
            }
            root.querySelectorAll('.ps-groups button').forEach(button => button.addEventListener('click', () => {
                filters.group = button.dataset.group; filters.brand = ''; filters.color = ''; page = 1; facets(); renderProducts();
            }));
            let searchTimer;
            search.addEventListener('input', function () {
                clearTimeout(searchTimer);
                searchTimer = setTimeout(() => { filters.search = search.value; page = 1; facets(); renderProducts(); }, 120);
            });
            brand.addEventListener('change', () => { filters.brand = brand.value; filters.color = ''; page = 1; facets(); renderProducts(); });
            color.addEventListener('change', () => { filters.color = color.value; page = 1; renderProducts(); });
            ['construction', 'coating'].forEach(name => {
                root.querySelector('.ps-' + name).addEventListener('change', event => {
                    filters[name] = event.target.value; page = 1; renderProducts();
                });
            });
            root.querySelectorAll('.ps-dimension').forEach(field => {
                const axis = field.dataset.axis;
                const values = Array.from(new Set(cfg.items.flatMap(item => item[axis === 'thickness' ? 'thicknesses' : axis + 's'] || [])))
                    .filter(value => Number.isFinite(value) && value > 0).sort((a, b) => a - b);
                const options = field.querySelector('.ps-dimension-options');
                const checks = [];
                const caption = field.querySelector('.ps-dimension-value');
                const updateCaption = () => {
                    const selected = checks.filter(input => input.checked);
                    caption.textContent = selected.length ? selected.map(input => input.dataset.label).join(', ')
                        : axisEmpty(axis);
                    field.querySelector('summary').setAttribute('aria-label', (axisTitle(axis) + ': ') + caption.textContent);
                    field.querySelector('summary').title = caption.textContent;
                };
                if (axis === 'length') values.push('custom');
                if (!values.length) options.append(element('p', '', 'Brak danych w atrybutach produktów.'));
                values.forEach(value => {
                    const label = element('label', 'ps-dimension-option');
                    const check = element('input'); check.type = 'checkbox'; check.value = String(value);
                    const text = value === 'custom' ? 'Na wymiar' : value.toLocaleString('pl-PL', { maximumFractionDigits: 3 }) + ' mm';
                    check.dataset.label = text;
                    check.setAttribute('aria-label', (axisTitle(axis) + ': ') + text);
                    check.addEventListener('change', () => {
                        filters[axis] = checks.filter(input => input.checked).map(input => input.value === 'custom' ? 'custom' : Number(input.value));
                        updateCaption(); page = 1; renderProducts();
                    });
                    checks.push(check); label.append(check, element('span', '', text)); options.append(label);
                });
                const reset = () => { checks.forEach(check => { check.checked = false; }); filters[axis] = null; updateCaption(); };
                dimensionResets.push(reset);
            });
            root.querySelectorAll('.ps-reset-filters').forEach(button => button.addEventListener('click', resetFilters));
            root.querySelector('.ps-clear').addEventListener('click', () => { model.selected.clear(); persist(); updateSelection(); notify('Zestaw został wyczyszczony.'); });
            root.querySelector('.ps-order').addEventListener('submit', function (event) {
                if (!cfg.enabled || !model.selected.size) { event.preventDefault(); return; }
                ids.value = JSON.stringify(model.ids()); submit.disabled = true; submit.textContent = 'Dodawanie zestawu…';
            });
            const syncDimensionAppearance = () => {
                const style = getComputedStyle(root.querySelector('.ps-construction'));
                root.querySelectorAll('.ps-dimension > summary').forEach(summary => {
                    ['fontFamily','fontSize','fontWeight','lineHeight','letterSpacing','color','backgroundColor',
                        'borderTopWidth','borderRightWidth','borderBottomWidth','borderLeftWidth',
                        'borderTopStyle','borderRightStyle','borderBottomStyle','borderLeftStyle',
                        'borderTopColor','borderRightColor','borderBottomColor','borderLeftColor',
                        'borderRadius','paddingTop','paddingBottom','paddingLeft'].forEach(name => { summary.style[name] = style[name]; });
                    summary.style.minHeight = (parseFloat(style.height) || parseFloat(style.minHeight) || 44) + 'px';
                    if (style.appearance !== 'none') summary.style.backgroundColor = 'Canvas';
                    summary.style.paddingLeft = Math.max(2, parseFloat(style.paddingLeft) || 0) + 'px';
                });
            };
            window.addEventListener('resize', syncDimensionAppearance, {passive:true});
            syncDimensionAppearance();
            const updateMobile = () => {
                details.open = !small.matches;
                root.querySelector('.ps-mobile-filters').open = !small.matches;
            };
            if (small.addEventListener) small.addEventListener('change', updateMobile); else small.addListener(updateMobile);
            const summaryAction = root.querySelector('.ps-mobile-action');
            const reserveSummarySpace = () => {
                root.style.setProperty('--ps-summary-space', Math.ceil(root.querySelector('.ps-order').getBoundingClientRect().height) + 'px');
            };
            details.addEventListener('toggle', () => { summaryAction.textContent = details.open ? 'Ukryj zestaw' : 'Pokaż zestaw'; reserveSummarySpace(); });
            if (window.ResizeObserver) {
                const observer = new ResizeObserver(reserveSummarySpace);
                observer.observe(root.querySelector('.ps-order'));
            }
            updateMobile(); reserveSummarySpace();
            const pick = cfg.pickKey ? model.byKey.get(cfg.pickKey) : model.byId.get(Number(cfg.pickId));
            if (pick && cfg.enabled) {
                const result = model.choose(pick.key, true);
                if (result.ok) { filters.group = pick.group; persist(); }
                else notify('Zestaw osiągnął limit. Usuń jedną próbkę, aby dodać wybrany materiał.');
            }
            facets(); renderProducts();
            window.addEventListener('pageshow', function (event) {
                if (!event.persisted) return;
                updateSelection(); submit.textContent = 'Dodaj zestaw do koszyka →';
            });
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize); else initialize();
}());
