<?php
defined('ABSPATH') || exit;
$fields=Pimex_Compare::ordered_filters();
?>
<pimex-compare-app style="display:block;width:100%" data-pimex-version="<?php echo esc_attr(Pimex_Compare::VERSION); ?>">
<template shadowrootmode="open">
<?php echo Pimex_Compare::styles(); ?>
<section class="pmc-app" aria-label="Dobierz i porównaj deski PIMEX">
<script type="application/json" class="pmc-config"><?php echo wp_json_encode($config,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?></script>
<header class="pmc-hero"><h2>Dobierz i porównaj deski</h2><p>Wybierz do 6 produktów i porównaj ich parametry.</p></header>
<?php if(empty($config['items'])){?><p class="pmc-message" role="status">Katalog porównania jest przygotowywany. Zajrzyj tu ponownie lub zobacz <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">produkty w sklepie</a>.</p><?php } ?>
<div class="pmc-layout">
<aside class="pmc-sidebar" aria-label="Filtry produktów">
<div class="pmc-category-picker" role="group" aria-label="Rodzaj desek">
<div class="pmc-category-options">
<button type="button" data-category="Deski tarasowe" aria-pressed="false">Deski tarasowe</button>
<button type="button" data-category="Deski elewacyjne" aria-pressed="false">Deski elewacyjne</button>
<button type="button" data-category="Lamele elewacyjne" aria-pressed="false">Lamele elewacyjne</button>
</div>
<button type="button" class="pmc-category-all" data-category="" hidden>Pokaż wszystkie</button>
</div>
<details class="pmc-filters"><summary>Filtry <span class="pmc-filter-count"></span></summary><div class="pmc-filter-content">
<?php foreach($fields as $field=>$label){ if(strpos($field,'price_')===0){ $unit=substr($field,6); ?>
<details class="pmc-rate-filter" data-unit="<?php echo esc_attr($unit); ?>"><summary><?php echo esc_html($label); ?></summary>
<div class="pmc-rate-fields">
<label>Od <input type="number" min="0" step="0.01" inputmode="decimal" data-rate="<?php echo esc_attr($unit); ?>" data-bound="min" aria-label="<?php echo esc_attr($label.' od'); ?>" placeholder="Bez minimum"></label>
<label>Do <input type="number" min="0" step="0.01" inputmode="decimal" data-rate="<?php echo esc_attr($unit); ?>" data-bound="max" aria-label="<?php echo esc_attr($label.' do'); ?>" placeholder="Bez maksimum"></label>
<span>zł / <?php echo esc_html($unit==='mb'?'mb':'m²'); ?></span>
</div></details>
<?php }else{ ?><details class="pmc-filter" data-field="<?php echo esc_attr($field); ?>"><summary><?php echo esc_html($label); ?><span class="pmc-option-count"></span></summary><div class="pmc-options" role="group" aria-label="<?php echo esc_attr($label); ?>"></div></details><?php }} ?>
<p class="pmc-rate-status" role="status" aria-live="polite"></p><button type="button" class="pmc-rate-retry" hidden>Spróbuj pobrać ceny ponownie</button>
<p class="pmc-hint">Cena za m² wg szerokości krycia, a przy jej braku wg szerokości deski. Model pasuje, gdy jedna z jego długości mieści się w wybranych zakresach.</p>
<p class="pmc-hint">Wymiary w mm. Możesz zaznaczyć kilka opcji. Produkcja na wymiar pasuje do każdej długości.</p>
<button type="button" class="pmc-reset">Wyczyść filtry</button>
</div></details>
</aside>
<div class="pmc-catalog">
<div class="pmc-toolbar"><p class="pmc-results" aria-live="polite"></p><div class="pmc-tools">
<button type="button" class="pmc-search-toggle" aria-label="Szukaj produktów" aria-expanded="false"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 5 5"></path></svg></button>
<button type="button" class="pmc-reset">Wyczyść filtry</button>
</div></div>
<div class="pmc-search-box" hidden><input type="search" class="pmc-search" aria-label="Model, producent lub kolor" placeholder="Szukaj modelu, producenta lub koloru" autocomplete="off"></div>
<div class="pmc-chips" aria-label="Aktywne filtry" hidden></div>
<div class="pmc-quick-selection" aria-label="Szybkie porównanie">
<strong class="pmc-quick-count">Wybrano 0 z 6</strong><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button>
</div>
<div class="pmc-grid"></div>
<div class="pmc-empty" hidden><h3>Brak produktów spełniających te warunki</h3><p>Zmień filtry lub wyszukiwane hasło.</p><button type="button" class="pmc-reset">Pokaż wszystkie produkty</button></div>
<nav class="pmc-pages" aria-label="Strony produktów"></nav>
</div></div>
<div class="pmc-selection" aria-label="Produkty do porównania">
<strong class="pmc-selected-count">Wybrano 0 z 6</strong><ul class="pmc-selected"></ul><div class="pmc-selection-actions"><button type="button" class="pmc-clear">Wyczyść</button><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button></div>
</div>
<div class="pmc-mobile-dock" hidden aria-label="Porównaj wybrane produkty">
<strong class="pmc-dock-count">Wybrano 0 z 6</strong><button type="button" class="pmc-show pmc-primary" disabled>Porównaj (0)</button>
</div>
<p class="pmc-feedback" role="status" aria-live="polite"></p>
<section class="pmc-comparison" hidden aria-label="Porównanie produktów">
<div class="pmc-table-toolbar"><h2 tabindex="-1">Porównanie produktów</h2><label class="pmc-option"><input type="checkbox" class="pmc-differences"><span>Pokaż tylko różnice</span></label><button type="button" class="pmc-close-table">Wróć do wyboru</button></div>
<div class="pmc-table-navigation"><button type="button" class="pmc-table-prev" aria-label="Poprzednie produkty">←</button><p class="pmc-table-hint">Przesuń tabelę palcem lub użyj strzałek.<span class="pmc-table-position" aria-live="polite"></span></p><button type="button" class="pmc-table-next" aria-label="Kolejne produkty">→</button></div>
<div class="pmc-table-scroll" tabindex="0" role="region" aria-label="Tabela porównania produktów"></div>
<p class="pmc-identical" hidden>Porównywane produkty mają takie same wartości dostępnych parametrów.</p>
<p class="pmc-hint">Ceny i dostępność mogą się zmienić. Ostateczne warunki sprawdzisz na karcie produktu. Brak danych oznacza brak odpowiedniego atrybutu w sklepie.</p>
</section>
</section>
</template>
<noscript><p>Włącz JavaScript, aby filtrować i porównywać deski. Produkty są dostępne także w sklepie.</p></noscript>
</pimex-compare-app>
