=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 3.0.0
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Odizolowany responsywny
interfejs, filtry atrybutów, niezależna dostępność, edytowalne ceny,
podsumowanie i osobna dostawa zestawu. Zachowuje ustawienia poprzedniej wersji.

== Installation ==
Prześlij ZIP i zastąp istniejącą wtyczkę. Zachowaj stronę [pimex_probki]
i produkt techniczny. Ustawienia: WooCommerce > Próbki PIMEX.
Po aktualizacji wyczyść cache strony i przeglądarki.

== Changelog ==
= 3.0.0 =
Nowy szablon i jeden arkusz interfejsu w odizolowanym komponencie.
Jedna struktura wszystkich filtrów i wspólny mały checkbox.
Nowe adresy plików; style strony próbek dostarczane razem z widokiem.
Osobny mały arkusz dla przycisku produktu, bez ładowania całego interfejsu.
Zachowane zasady zakupu, ustawienia, cache i ochrona produktu technicznego.
Szczegóły testów: AKTUALIZACJA-3.0.0.txt.
