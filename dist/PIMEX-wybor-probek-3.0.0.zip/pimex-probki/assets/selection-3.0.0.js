(function (root, factory) {
    'use strict';
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.PimexSamples3Selection = factory();
}(typeof window !== 'undefined' ? window : globalThis, function () {
    'use strict';
    function normalized(text) {
        return String(text || '').toLocaleLowerCase('pl').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ł/g, 'l');
    }
    class Selection {
        constructor(items, limit, price = 4, shipping = 14) {
            this.items = Array.isArray(items) ? items : [];
            this.limit = Math.max(1, Number(limit) || 12);
            this.unitCents = Math.round(Number(price) * 100);
            this.shippingCents = Math.round(Number(shipping) * 100);
            this.byKey = new Map();
            this.byId = new Map();
            this.items.forEach(item => { this.byKey.set(item.key, item); this.byId.set(Number(item.id), item); });
            this.searchTexts = new WeakMap();
            this.groupCounts = new Map([['', this.items.length]]);
            this.items.forEach(item => {
                this.searchTexts.set(item, normalized([item.label, item.title, item.brand, item.color, item.sku, item.series].join(' ')));
                if (item.group) this.groupCounts.set(item.group, (this.groupCounts.get(item.group) || 0) + 1);
            });
            this.selected = new Set();
        }
        choose(key, on) {
            if (!this.byKey.has(key)) return { ok: false, reason: 'missing' };
            if (on && this.byKey.get(key).available === false) return { ok: false, reason: 'unavailable' };
            if (on && !this.selected.has(key) && this.selected.size >= this.limit) return { ok: false, reason: 'limit' };
            if (on) this.selected.add(key); else this.selected.delete(key);
            return { ok: true };
        }
        restore(saved) {
            if (!Array.isArray(saved)) return;
            saved.slice(0, 500).forEach(value => {
                const item = typeof value === 'string' ? this.byKey.get(value) : this.byId.get(Number(value));
                if (item) this.choose(item.key, true);
            });
        }
        entries() { return Array.from(this.selected, key => this.byKey.get(key)).filter(Boolean); }
        ids() { return this.entries().map(item => Number(item.id)); }
        totals() {
            const count = this.selected.size;
            const subtotal = count * this.unitCents, shipping = count ? this.shippingCents : 0;
            return { count, subtotal: subtotal / 100, shipping: shipping / 100, total: (subtotal + shipping) / 100 };
        }
        filter(filters) {
            const f = filters || {}, query = normalized(f.search).trim().split(/\s+/).filter(Boolean);
            const matches = (selected, values) => {
                const wanted = Array.isArray(selected) ? selected : (selected ? [selected] : []);
                return !wanted.length || wanted.some(value => values.includes(value));
            };
            return this.items.filter(item => matches(f.group, [item.group])
                && matches(f.brand, [item.brand]) && matches(f.color, item.shades || [])
                && matches(f.construction, [item.construction]) && matches(f.coating, [item.coating])
                && matches(f.surface, item.surfaces || []) && matches(f.material, item.materials || [])
                && ['width', 'length', 'thickness'].every(axis => !f[axis] || !f[axis].length || (axis === 'length' && item.custom_length === true) || (item[axis === 'thickness' ? 'thicknesses' : axis + 's'] || []).some(value => f[axis].includes(value)))
                && query.every(word => this.searchTexts.get(item).includes(word)));
        }
    }
    return { Selection, normalized };
}));
