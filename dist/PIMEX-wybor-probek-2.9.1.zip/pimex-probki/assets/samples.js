(function () {
    'use strict';
    function initialize() {
        document.querySelectorAll('.pimex-samples.ps-v2').forEach(function (root, rootIndex) {
            if (root.dataset.bound === 'yes' || !window.PimexSampleSelection) return;
            root.dataset.bound = 'yes';
            let cfg;
            const configNode = root.querySelector('script.ps-config');
            try { cfg = JSON.parse(configNode ? configNode.textContent : root.dataset.config); } catch (_) { return; }
            if (configNode) configNode.remove();
            const model = new window.PimexSampleSelection.Selection(cfg.items, cfg.max, cfg.price, cfg.shipping);
            const grid = root.querySelector('.ps-grid'), list = root.querySelector('.ps-selected');
            const search = root.querySelector('.ps-search'), brand = root.querySelector('.ps-brand'), color = root.querySelector('.ps-color-filter');
            const ids = root.querySelector('.ps-ids'), submit = root.querySelector('.ps-submit'), feedback = root.querySelector('.ps-feedback');
            const pager = root.querySelector('.ps-pagination');
            const filters = { group: [], brand: [], color: [], search: '', construction: [], coating: [], surface: [], material: [], width: null, length: null, thickness: null };
            const dimensionResets = [];
            const searchToggle = root.querySelector('.ps-search-toggle'), searchBox = root.querySelector('.ps-search-box');
            function showSearch(open) {
                if (!searchBox || !searchToggle) return;
                searchBox.hidden = !open; searchToggle.setAttribute('aria-expanded', String(open));
                if (open) search.focus();
            }
            if (searchToggle && searchBox) {
                searchBox.id = 'pimex-search-' + rootIndex;
                searchToggle.setAttribute('aria-controls', searchBox.id);
                searchToggle.addEventListener('click', () => showSearch(searchBox.hidden));
                search.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); showSearch(false); searchToggle.focus(); } });
            }
            const small = window.matchMedia('(max-width: 767px)');
            let page = 1;
            const money = value => value.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' zł';
            const element = (tag, className, text) => {
                const node = document.createElement(tag);
                if (className) node.className = className;
                if (text !== undefined) node.textContent = text;
                return node;
            };
            const shortName = item => (item.title || item.label) + (item.color ? ' — ' + item.color : '');
            const axisTitle = axis => ({width:'Szerokość deski', length:'Długość deski', thickness:'Grubość deski'})[axis];
            const axisEmpty = axis => ({width:'Wszystkie szerokości', length:'Wszystkie długości', thickness:'Wszystkie grubości'})[axis];
            function persist() {
                try { localStorage.setItem(cfg.storage, JSON.stringify(Array.from(model.selected))); } catch (_) {}
            }
            function notify(text) { feedback.textContent = text; }
            function updateSelection() {
                const totals = model.totals();
                list.replaceChildren();
                model.entries().forEach(function (item) {
                    const li = element('li'), image = element('img'), info = element('span', 'ps-selected-info');
                    image.src = item.image_url; image.alt = ''; image.loading = 'lazy';
                    info.append(element('strong', '', item.color || item.title), element('span', '', item.color ? item.title : item.brand));
                    const remove = element('button', 'button ps-remove', '×');
                    remove.type = 'button'; remove.setAttribute('aria-label', 'Usuń próbkę: ' + shortName(item));
                    remove.addEventListener('click', function () { model.choose(item.key, false); persist(); updateSelection(); notify('Usunięto próbkę: ' + shortName(item)); });
                    li.append(image, info, remove); list.append(li);
                });
                root.querySelector('.ps-count').textContent = String(totals.count);
                root.querySelector('.ps-quantity-label').textContent = 'Próbki · ' + totals.count + ' szt.';
                root.querySelector('.ps-subtotal').textContent = money(totals.subtotal);
                root.querySelector('.ps-shipping').textContent = totals.count ? money(totals.shipping) : '—';
                root.querySelector('.ps-grand-total').textContent = money(totals.total);
                root.querySelector('.ps-empty-selection').hidden = totals.count > 0;
                root.querySelector('.ps-clear').disabled = totals.count === 0;
                submit.disabled = !cfg.enabled || totals.count === 0;
                ids.value = JSON.stringify(model.ids());
                grid.querySelectorAll('.ps-check').forEach(function (check) {
                    const on = model.selected.has(check.dataset.key);
                    check.checked = on;
                    const card = check.closest('.ps-card');
                    card.classList.toggle('is-selected', on);
                });
            }
            const choiceFields = {group: root.querySelector('.ps-groups'), brand, color,
                construction: root.querySelector('.ps-construction'), coating: root.querySelector('.ps-coating'),
                surface: root.querySelector('.ps-surface'), material: root.querySelector('.ps-material')};
            const choiceLabels = {group:'Zastosowanie',brand:'Producent',color:'Kolor',construction:'Konstrukcja',coating:'Powłoka',surface:'Powierzchnia',material:'Materiał'};
            Object.keys(choiceFields).forEach(name => { if (!choiceFields[name]) delete choiceFields[name]; });
            const optionKeys = new Map();
            function syncChoices() {
                Object.keys(choiceFields).forEach(name => choiceFields[name].querySelectorAll('input').forEach(input => {
                    input.checked = input.value ? filters[name].includes(input.value) : !filters[name].length;
                }));
            }
            function fillChoices(name, values, placeholder) {
                if (!choiceFields[name]) return;
                const sorted = Array.from(new Set(values.filter(Boolean))).sort((a,b)=>a.localeCompare(b,'pl'));
                const key = JSON.stringify(sorted);
                // Zachowaj zaznaczenia i fokus, jeśli lista się nie zmieniła.
                if (optionKeys.get(name) === key) return;
                optionKeys.set(name, key);
                const field = choiceFields[name]; field.replaceChildren();
                [['', placeholder], ...sorted.map(value=>[value,value])].forEach(([value,text])=>{
                    const label = element('label','ps-dimension-option'), input = element('input');
                    input.type = 'checkbox'; input.value = value;
                    label.append(input,element('span','',text)); field.append(label);
                });
                if (!sorted.length) field.append(element('p','','Brak danych w atrybutach produktów.'));
            }
            let choicesReady = false;
            function facets() {
                if (!choicesReady) {
                fillChoices('brand', cfg.items.map(item=>item.brand), 'Wszyscy producenci');
                fillChoices('surface', cfg.items.flatMap(item=>item.surfaces || []), 'Wszystkie powierzchnie');
                fillChoices('material', cfg.items.flatMap(item=>item.materials || []), 'Wszystkie materiały');
                choicesReady = true;
                }
                syncChoices();
            }
            function changeChoice(item, check) {
                const outcome = model.choose(item.key, check.checked);
                if (!outcome.ok) {
                    check.checked = false;
                    notify(outcome.reason === 'unavailable' ? 'Ta próbka jest chwilowo niedostępna.' : 'Możesz wybrać maksymalnie ' + cfg.max + ' różnych próbek. Usuń jedną z zestawu, aby wybrać kolejną.');
                    if (small.matches) root.querySelector('.ps-feedback').scrollIntoView({block:'nearest'});
                    return;
                }
                persist(); updateSelection();
                notify(check.checked ? 'Dodano próbkę: ' + shortName(item) : 'Usunięto próbkę: ' + shortName(item));
            }
            function productCard(item) {
                const article = element('article', 'ps-card'), label = element('label', 'ps-choice');
                const check = element('input', 'ps-check'); check.type = 'checkbox'; check.dataset.key = item.key;
                const unavailable = item.available === false;
                article.classList.toggle('is-unavailable', unavailable);
                check.disabled = !cfg.enabled || unavailable; check.setAttribute('aria-label', 'Wybierz próbkę: ' + shortName(item));
                check.addEventListener('change', () => changeChoice(item, check));
                const frame = element('span', 'ps-image'), image = element('img');
                image.src = item.image_url; image.alt = shortName(item); image.loading = 'lazy'; image.decoding = 'async';
                if (unavailable) {
                    image.style.setProperty('filter', 'grayscale(1)', 'important');
                    image.style.setProperty('-webkit-filter', 'grayscale(1)', 'important');
                    image.style.setProperty('opacity', '0.55', 'important');
                }
                frame.append(image);
                if (unavailable) frame.append(element('span', 'ps-unavailable', 'Chwilowo niedostępne'));
                const info = element('span', 'ps-info');
                info.append(element('span', 'ps-brand-label', item.brand), element('span', 'ps-title', item.title),
                    element('strong', 'ps-color-name', item.color || 'Kolor zgodny ze zdjęciem'));
                const axes = [item.thicknesses || [], item.widths || [], item.lengths || []];
                if (axes.some(values => values.length)) {
                    const formatDimension = values => values.length ? values.map(value => Number(value).toLocaleString('pl-PL', {maximumFractionDigits:3, useGrouping:false})).join('/') : '—';
                    const dimensions = element('span', 'ps-card-dimensions', axes.map(formatDimension).join(' × '));
                    dimensions.setAttribute('aria-label', 'Wymiary w mm: grubość × szerokość × długość: ' + dimensions.textContent + (item.custom_length ? '. Długość również na wymiar.' : ''));
                    info.append(dimensions);
                }
                if (item.custom_length) info.append(element('span', 'ps-card-custom', 'produkcja na wymiar'));
                const price = element('span', 'ps-price'); price.append(element('span', '', 'Próbka'), element('strong', '', money(model.unitCents / 100)));
                info.append(price); label.append(check, frame, info);
                const link = element('a', 'ps-source', 'Zobacz produkt ↗'); link.href = item.url; link.target = '_blank'; link.rel = 'noopener';
                article.append(label, link); return article;
            }
            function renderPager(total) {
                pager.replaceChildren();
                if (total <= 1) return;
                function pageButton(number, text, disabled) {
                    const button = element('button', 'button', text); button.type = 'button'; button.disabled = disabled;
                    if (number === page && !disabled) button.setAttribute('aria-current', 'page');
                    button.addEventListener('click', () => { page = number; renderProducts(); root.querySelector('.ps-result-line').scrollIntoView({ block: 'start', behavior: 'auto' }); });
                    pager.append(button);
                }
                pageButton(page - 1, '← Poprzednia', page === 1);
                const visible = new Set([1, total, page - 1, page, page + 1]);
                let previous = 0;
                Array.from(visible).filter(n => n > 0 && n <= total).sort((a, b) => a - b).forEach(n => {
                    if (previous && n - previous > 1) pager.append(element('span', '', '…'));
                    pageButton(n, String(n), false); previous = n;
                });
                pageButton(page + 1, 'Następna →', page === total);
            }
            function renderActiveFilters() {
                const box = root.querySelector('.ps-active-filters');
                box.replaceChildren();
                function chip(name, label, clear) {
                    const button = element('button', 'button ps-filter-chip', label + ' ×');
                    button.type = 'button'; button.dataset.filter = name;
                    button.setAttribute('aria-label', 'Usuń filtr: ' + label);
                    button.addEventListener('click', () => { if (clear() === true) return; page = 1; facets(); renderProducts(); });
                    box.append(button);
                }
                if (filters.search.trim()) chip('search', 'Szukaj: ' + filters.search.trim(), () => { clearTimeout(searchTimer); filters.search = ''; search.value = ''; });
                Object.keys(choiceFields).forEach(name => {
                    filters[name].forEach(value=>{
                        const option = Array.from(choiceFields[name].querySelectorAll('input')).find(input=>input.value===value);
                        const text = option ? option.closest('label').querySelector('span').firstChild.textContent.trim() : value;
                        chip(name, choiceLabels[name] + ': ' + text, () => { filters[name] = filters[name].filter(selected=>selected!==value); syncChoices(); });
                    });
                });
                ['width','length','thickness'].forEach(axis => {
                    (filters[axis] || []).forEach(value => {
                        const check = Array.from(root.querySelectorAll('[data-axis="' + axis + '"] input')).find(input => input.value === String(value));
                        const label = (axisTitle(axis).replace(' deski', '') + ': ') + (check ? check.dataset.label : value);
                        chip(axis, label, () => { if (check) { check.checked = false; check.dispatchEvent(new Event('change')); return true; } });
                    });
                });
                box.hidden = !box.childElementCount;
                const extra = box.childElementCount;
                root.querySelector('.ps-more-count').textContent = extra ? ' (' + extra + ')' : '';
            }
            function renderProducts() {
                const matching = model.filter(filters), size = Number(cfg.pageSize) || 18;
                const pages = Math.max(1, Math.ceil(matching.length / size)); page = Math.min(page, pages);
                grid.replaceChildren();
                matching.slice((page - 1) * size, page * size).forEach(item => grid.append(productCard(item)));
                root.querySelector('.ps-results').textContent = matching.length ? 'Próbki: ' + matching.length + ' · dostępne: ' + matching.filter(item => item.available !== false).length : 'Brak wyników';
                root.querySelector('.ps-empty').hidden = matching.length > 0;
                root.querySelectorAll('.ps-groups input').forEach(input => {
                    input.closest('label').querySelector('.ps-group-count').textContent = String(model.groupCounts.get(input.value) || 0);
                });
                renderPager(pages); renderActiveFilters(); updateSelection();
            }
            function resetFilters() {
                clearTimeout(searchTimer); showSearch(false);
                Object.keys(choiceFields).forEach(name=>{ filters[name] = []; });
                filters.search = ''; filters.width = null; filters.length = null; filters.thickness = null;
                syncChoices(); dimensionResets.forEach(reset => reset()); search.value = ''; page = 1; facets(); renderProducts();
            }
            let searchTimer;
            search.addEventListener('input', function () {
                clearTimeout(searchTimer);
                searchTimer = setTimeout(() => { filters.search = search.value; page = 1; facets(); renderProducts(); }, 120);
            });
            Object.keys(choiceFields).forEach(name => {
                choiceFields[name].addEventListener('change', event => {
                    if (!event.target.matches('input[type="checkbox"]')) return;
                    filters[name] = event.target.value ? Array.from(choiceFields[name].querySelectorAll('input:checked')).map(input=>input.value).filter(Boolean) : [];
                    page = 1; facets(); renderProducts();
                });
            });
            root.querySelectorAll('.ps-dimension').forEach(field => {
                const axis = field.dataset.axis;
                const values = Array.from(new Set(cfg.items.flatMap(item => item[axis === 'thickness' ? 'thicknesses' : axis + 's'] || [])))
                    .filter(value => Number.isFinite(value) && value > 0).sort((a, b) => a - b);
                const options = field.querySelector('.ps-dimension-options');
                const checks = [];
                const allLabel = element('label', 'ps-dimension-option');
                const allCheck = element('input'); allCheck.type = 'checkbox'; allCheck.value = ''; allCheck.checked = true;
                allCheck.setAttribute('aria-label', axisEmpty(axis));
                allLabel.append(allCheck, element('span', '', axisEmpty(axis))); options.append(allLabel);
                const caption = field.querySelector('.ps-dimension-value');
                const updateCaption = () => {
                    const selected = checks.filter(input => input.checked);
                    caption.textContent = selected.length ? selected.map(input => input.dataset.label).join(', ')
                        : axisEmpty(axis);
                    caption.hidden = true;
                    allCheck.checked = !selected.length;
                    field.querySelector('summary').setAttribute('aria-label', (axisTitle(axis) + ': ') + caption.textContent);
                    field.querySelector('summary').title = caption.textContent;
                };
                if (axis === 'length') values.push('custom');
                if (!values.length) options.append(element('p', '', 'Brak danych w atrybutach produktów.'));
                values.forEach(value => {
                    const label = element('label', 'ps-dimension-option');
                    const check = element('input'); check.type = 'checkbox'; check.value = String(value);
                    const text = value === 'custom' ? 'Na wymiar' : value.toLocaleString('pl-PL', { maximumFractionDigits: 3 }) + ' mm';
                    check.dataset.label = text;
                    check.setAttribute('aria-label', (axisTitle(axis) + ': ') + text);
                    check.addEventListener('change', () => {
                        filters[axis] = checks.filter(input => input.checked).map(input => input.value === 'custom' ? 'custom' : Number(input.value));
                        updateCaption(); page = 1; renderProducts();
                    });
                    checks.push(check); label.append(check, element('span', '', text)); options.append(label);
                });
                const reset = () => { checks.forEach(check => { check.checked = false; }); filters[axis] = null; updateCaption(); };
                allCheck.addEventListener('change', () => { reset(); page = 1; renderProducts(); });
                updateCaption(); dimensionResets.push(reset);
            });
            // Theme builders may replace a reset button; delegate to the stable selector root.
            root.addEventListener('click', event => {
                const button = event.target.closest('.ps-reset-filters');
                if (!button || !root.contains(button)) return;
                event.preventDefault(); event.stopPropagation(); resetFilters();
            }, true);
            root.querySelector('.ps-clear').addEventListener('click', () => { model.selected.clear(); persist(); updateSelection(); notify('Zestaw został wyczyszczony.'); });
            root.querySelector('.ps-order').addEventListener('submit', function (event) {
                if (!cfg.enabled || !model.selected.size) { event.preventDefault(); return; }
                ids.value = JSON.stringify(model.ids()); submit.disabled = true; submit.textContent = 'Dodawanie zestawu…';
            });
            const updateMobile = () => {
                root.querySelector('.ps-mobile-filters').open = !small.matches;
            };
            if (small.addEventListener) small.addEventListener('change', updateMobile); else small.addListener(updateMobile);
            updateMobile();
            const pick = cfg.pickKey ? model.byKey.get(cfg.pickKey) : model.byId.get(Number(cfg.pickId));
            if (pick && cfg.enabled) {
                const result = model.choose(pick.key, true);
                if (result.ok) { filters.group = pick.group ? [pick.group] : []; persist(); }
                else notify('Zestaw osiągnął limit. Usuń jedną próbkę, aby dodać wybrany materiał.');
            }
            facets(); renderProducts();
            window.addEventListener('pageshow', function (event) {
                if (!event.persisted) return;
                updateSelection(); submit.textContent = 'Dodaj zestaw do koszyka →';
            });
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize); else initialize();
}());
