=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.9.1
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.9.1 =
Wspólny styl nazw, opcji i małych checkboxów na telefonie i komputerze.
Usunięta etykieta Wybrano. Zielony przycisk Dodaj zestaw do koszyka,
białe przyciski czyszczenia z zielonym obramowaniem.
Zachowano optymalizację cache i bezpośrednie dodawanie próbki z produktu.
Szczegóły testów: AKTUALIZACJA-2.9.1.txt.
