<?php
defined('ABSPATH') || exit;

final class Pimex_Samples_Catalog {
    public static function invalidate() {
        update_option('pimex_samples_catalog_revision', microtime(true), false);
    }

    public static function attribute($product, $labels) {
        foreach ($product->get_attributes() as $name => $attribute) {
            $label = sanitize_title(wc_attribute_label($name, $product));
            if (in_array($label, $labels, true)) {
                return trim(wp_strip_all_tags($product->get_attribute($name)));
            }
        }
        return '';
    }

    public static function shades() {
        return array('grey' => 'Szarości i antracyty', 'brown' => 'Brązy i odcienie drewna',
            'beige' => 'Beże i kremy', 'red' => 'Rudości i czerwienie', 'black' => 'Czernie');
    }

    public static function normalize($text) {
        return strtolower(remove_accents(wp_strip_all_tags($text)));
    }

    public static function color_groups($color, $key) {
        $manual = get_option('pimex_samples_shades', array());
        if (array_key_exists($key, $manual)) { return array_values(array_intersect((array) $manual[$key], array_keys(self::shades()))); }
        $text = self::normalize($color);
        // Te nazwy zawsze wymagają jawnej decyzji administratora.
        if (preg_match('/\\b(basalt|antique)\\b/', $text)) { return array(); }
        $rules = array(
            'grey' => 'anthracite|anthracyt|antracyt|graphite|grey|gray|szary|szara|grafitowy|grafit',
            'brown' => 'teak|walnut|oak|dab|debowy|orzech|braz|brazowy',
            'beige' => 'cream latte|cream|bezowy|bez|kremowy|krem',
            'red' => 'copper|red cedar|oranz|miedziany|czerwony|rudy',
            'black' => 'ebony|czarny|black|burnt wood');
        $groups = array();
        foreach ($rules as $group => $words) {
            if (preg_match('/(?<![a-z])(?:' . $words . ')(?![a-z])/', $text)) { $groups[] = $group; }
        }
        return $groups;
    }

    public static function dimensions($text, $default_unit = 'mm') {
        // Jednostka atrybutu lub jawna jednostka po liczbie; brak danych pozostaje pusty.
        $text = self::normalize($text);
        if (preg_match('/(mm|cm|m)\\s*$/', $text, $unit_match)) { $default_unit = $unit_match[1]; }
        preg_match_all('/(\\d+(?:[.,]\\d+)?)\\s*(mm|cm|m)?(?![a-z])/', $text, $matches, PREG_SET_ORDER);
        $values = array();
        foreach ($matches as $match) {
            $unit = !empty($match[2]) ? $match[2] : $default_unit;
            $value = (float) str_replace(',', '.', $match[1]) * ($unit === 'm' ? 1000 : ($unit === 'cm' ? 10 : 1));
            if ($value > 0) { $values[] = round($value, 3); }
        }
        return array_values(array_unique($values));
    }

    public static function product_dimensions($product, $axis) {
        $values = array();
        foreach ($product->get_attributes() as $name => $attribute) {
            $label = self::normalize(wc_attribute_label($name, $product));
            $needle = $axis === 'width' ? 'szerokosc' : 'dlugosc';
            if (strpos($label, $needle) === false) { continue; }
            $unit = preg_match('/(?<![a-z])(mm|cm|m)(?![a-z])/', $label, $m) ? $m[1] : 'mm';
            $values = array_merge($values, self::dimensions($product->get_attribute($name), $unit));
        }
        if (!$values) {
            $value = $axis === 'width' ? $product->get_width() : $product->get_length();
            if ($value !== '') { $values = self::dimensions($value, get_option('woocommerce_dimension_unit', 'cm')); }
        }
        return array_values(array_unique($values));
    }

    public static function merge($a, $b) {
        $chosen = !$a['available'] && $b['available'] ? $b : $a;
        foreach (array('widths', 'lengths') as $axis) {
            $chosen[$axis] = array_values(array_unique(array_merge($a[$axis], $b[$axis])));
            sort($chosen[$axis], SORT_NUMERIC);
        }
        return $chosen;
    }

    private static function group($product) {
        $slugs = array();
        foreach ($product->get_category_ids() as $id) {
            foreach (array_merge(array($id), get_ancestors($id, 'product_cat', 'taxonomy')) as $tid) {
                $term = get_term($tid, 'product_cat');
                if ($term && !is_wp_error($term)) { $slugs[] = $term->slug; }
            }
        }
        if (in_array('lamele-kompozytowe', $slugs, true)) { return 'lamele'; }
        if (in_array('kompozytowe-elewacje', $slugs, true)) { return 'elewacje'; }
        return 'tarasy';
    }

    public static function describe($source, $parent, $variation_colors, $detail = null) {
        $brand = self::attribute($parent, array('producent', 'producent-marka', 'marka'));
        if ($brand === '' && taxonomy_exists('product_brand')) {
            $terms = get_the_terms($parent->get_id(), 'product_brand');
            if ($terms && !is_wp_error($terms)) { $brand = implode(' / ', wp_list_pluck($terms, 'name')); }
        }
        if ($brand === '') {
            foreach ($parent->get_category_ids() as $id) {
                foreach (get_ancestors($id, 'product_cat', 'taxonomy') as $ancestor) {
                    $term = get_term($ancestor, 'product_cat');
                    if ($term && !is_wp_error($term) && $term->slug === 'producenci') {
                        $leaf = get_term($id, 'product_cat');
                        if ($leaf && !is_wp_error($leaf)) { $brand = $leaf->name; break 2; }
                    }
                }
            }
        }
        $color = $variation_colors ? implode(', ', $variation_colors)
            : self::attribute($parent, array('kolor', 'color'));
        $series = self::attribute($parent, array('seria-system', 'seria', 'kolekcja'));
        $source['brand'] = $brand ?: 'Pozostałe';
        $source['color'] = $color;
        $source['series'] = $series;
        $source['title'] = $series ?: $parent->get_name();
        $source['group'] = self::group($parent);
        $source['image_url'] = $source['image'] ? wp_get_attachment_image_url($source['image'], 'woocommerce_thumbnail') : wc_placeholder_img_src();
        $source['image_url'] = $source['image_url'] ?: wc_placeholder_img_src();
        $source['sku'] = $parent->get_sku();
        // Konserwatywne usuwanie duplikatów osobnych długości: wymagane wszystkie dane profilu.
        $width = self::attribute($parent, array('szerokosc'));
        $thickness = self::attribute($parent, array('grubosc'));
        if ($series !== '' && $color !== '' && $width !== '' && $thickness !== '') {
            $identity = array($source['brand'], $series, $color, $width, $thickness, $source['group'],
                self::attribute($parent, array('konstrukcja')), self::attribute($parent, array('powierzchnia')));
            $source['key'] = 'profile:' . md5(wp_json_encode($identity));
        }
        $construction_value = $detail ? self::attribute($detail, array('konstrukcja')) : '';
        $construction = self::normalize($construction_value ?: self::attribute($parent, array('konstrukcja')));
        $source['construction'] = preg_match('/\\b(pelna|pelne|solid)\\b/', $construction) ? 'solid'
            : (preg_match('/\\b(komorowa|komorowe|hollow)\\b/', $construction) ? 'hollow' : '');
        $material_value = $detail ? self::attribute($detail, array('material')) : '';
        $material = self::normalize($material_value ?: self::attribute($parent, array('material')));
        $composite = strpos($material, 'kompozyt') !== false || preg_match('/\\bwpc\\b/', $material);
        if (!$composite && $material === '') {
            foreach ($parent->get_category_ids() as $id) {
                foreach (array_merge(array($id), get_ancestors($id, 'product_cat', 'taxonomy')) as $tid) {
                    $term = get_term($tid, 'product_cat');
                    if ($term && !is_wp_error($term) && in_array($term->slug, array('deski-kompozytowe', 'kompozytowe-elewacje', 'lamele-kompozytowe'), true)) { $composite = true; }
                }
            }
        }
        $source['coating'] = $composite ? (preg_match('/kompozyt\\s+drewniano[ -]+polimerowy/', $material) ? 'coated' : 'uncoated') : '';
        $source['shades'] = self::color_groups($color, $source['key']);
        $source['widths'] = self::product_dimensions($parent, 'width');
        $source['lengths'] = self::product_dimensions($parent, 'length');
        return $source;
    }

    public static function all() {
        $options = Pimex_Samples_1::options();
        $key = 'pimex_s2_catalog_' . md5(Pimex_Samples_1::VERSION . get_locale()
            . get_option('pimex_samples_catalog_revision', '0') . $options['excluded'] . wp_json_encode($options['excluded_keys']));
        $cached = get_transient($key);
        if (is_array($cached)) { return $cached; }
        $result = array();
        $page = 1;
        do {
            $query = new WP_Query(array('post_type' => 'product', 'post_status' => 'publish',
                'posts_per_page' => 200, 'paged' => $page, 'fields' => 'ids',
                'orderby' => 'ID', 'order' => 'ASC', 'tax_query' => array(array(
                    'taxonomy' => 'product_cat', 'field' => 'slug', 'include_children' => true,
                    'terms' => array('deski-kompozytowe', 'deski-drewniane', 'kompozytowe-elewacje', 'lamele-kompozytowe')))));
            foreach ($query->posts as $id) {
                $product = wc_get_product($id);
                if (!Pimex_Samples_1::allowed($product)) { continue; }
                foreach (Pimex_Samples_1::cards($product, true) as $sample) {
                    // Gdy pierwszy reprezentant jest wyłączony, zachowujemy inny dostępny.
                    if (!isset($result[$sample['key']]) || (!$result[$sample['key']]['available'] && $sample['available'])) {
                        $previous = $result[$sample['key']] ?? null;
                        $result[$sample['key']] = $previous ? self::merge($previous, $sample) : $sample;
                    } else { $result[$sample['key']] = self::merge($result[$sample['key']], $sample); }
                }
            }
            $page++;
        } while ($page <= (int) $query->max_num_pages);
        $result = array_values($result);
        usort($result, function($a, $b) {
            return strnatcasecmp($a['brand'] . ' ' . $a['title'] . ' ' . $a['color'], $b['brand'] . ' ' . $b['title'] . ' ' . $b['color']);
        });
        set_transient($key, $result, 30 * MINUTE_IN_SECONDS);
        return $result;
    }
}
