<?php defined('ABSPATH') || exit; ?>
<section class="pimex-samples ps-v2" data-config="<?php echo esc_attr(wp_json_encode($config)); ?>" aria-label="Wybór próbek PIMEX">
    <header class="ps-hero">
        <p class="ps-eyebrow">Próbki desek i lameli</p>
        <h2>Sprawdź materiał przed zakupem</h2>
        <p>Porównaj kolory i strukturę w swoim domu. Zaznacz próbki, które chcesz zamówić.</p>
        <div class="ps-terms"><span><strong>4 zł</strong> za próbkę</span><span><strong>14 zł</strong> za wysyłkę całego zestawu w Polsce</span></div>
    </header>
    <?php if (!$config['enabled']) : ?><p class="ps-status" role="status">Zamawianie próbek jest chwilowo wyłączone. Możesz obejrzeć dostępne materiały.</p><?php endif; ?>
    <nav class="ps-groups" aria-label="Wybierz zastosowanie">
        <button type="button" class="button" data-group="" aria-pressed="true">Wszystkie próbki <span></span></button>
        <button type="button" class="button" data-group="tarasy" aria-pressed="false">Deski tarasowe <span></span></button>
        <button type="button" class="button" data-group="elewacje" aria-pressed="false">Deski elewacyjne <span></span></button>
        <button type="button" class="button" data-group="lamele" aria-pressed="false">Lamele elewacyjne <span></span></button>
    </nav>
    <div class="ps-layout">
        <div class="ps-catalog">
            <div class="ps-filters">
                <label class="ps-search-label">Model, producent lub kolor<input class="ps-search" type="search" placeholder="np. Legro Basalt" autocomplete="off"></label>
                <label>Producent<select class="ps-brand"><option value="">Wszyscy producenci</option></select></label>
                <label>Odcień<select class="ps-color-filter"><option value="">Wszystkie odcienie</option>
                    <?php foreach (Pimex_Samples_Catalog::shades() as $key => $label) : ?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option><?php endforeach; ?>
                </select></label>
            </div>
            <details class="ps-more"><summary>Więcej filtrów</summary><div class="ps-extra-filters">
                <label>Konstrukcja<select class="ps-construction"><option value="">Wszystkie konstrukcje</option><option value="solid">Pełna</option><option value="hollow">Komorowa</option></select></label>
                <label>Powłoka<select class="ps-coating"><option value="">Wszystkie</option><option value="coated">Z powłoką polimerową</option><option value="uncoated">Bez powłoki polimerowej</option></select></label>
                <fieldset class="ps-dimension" data-axis="width"><legend>Szerokość deski</legend>
                    <output aria-live="polite"></output>
                    <label>Od<input type="range" class="ps-range-min" step="any" aria-label="Szerokość deski od (mm)"></label>
                    <label>Do<input type="range" class="ps-range-max" step="any" aria-label="Szerokość deski do (mm)"></label>
                    <button type="button" class="button ps-range-reset">Dowolna</button>
                </fieldset>
                <fieldset class="ps-dimension" data-axis="length"><legend>Długość deski</legend>
                    <output aria-live="polite"></output>
                    <label>Od<input type="range" class="ps-range-min" step="any" aria-label="Długość deski od (mm)"></label>
                    <label>Do<input type="range" class="ps-range-max" step="any" aria-label="Długość deski do (mm)"></label>
                    <button type="button" class="button ps-range-reset">Dowolna</button>
                </fieldset>
            </div><p>Wymiary dotyczą pełnych desek, nie próbek. Próbka pasuje, gdy jeden z jej wymiarów mieści się w zakresie. Brak wymiaru wyklucza ją tylko przy aktywnym filtrze.</p></details>
            <div class="ps-result-line"><p class="ps-results" aria-live="polite"></p><button type="button" class="button ps-reset-filters">Wyczyść filtry</button></div>
            <div class="ps-grid"></div>
            <div class="ps-empty" hidden><h3>Nie znaleźliśmy takich próbek</h3><p>Zmień model, producenta, kolor lub zastosowanie.</p><button type="button" class="button ps-reset-filters">Pokaż wszystkie próbki</button></div>
            <nav class="ps-pagination" aria-label="Strony wyboru próbek"></nav>
            <p class="ps-photo-note">Zdjęcia przedstawiają pełny produkt lub realizację. Otrzymasz próbkę materiału. Kolor na ekranie może różnić się od rzeczywistego.</p>
        </div>
        <form method="post" class="ps-order" action="<?php echo esc_url(get_permalink()); ?>">
            <?php wp_nonce_field('pimex_samples_order', 'pimex_samples_nonce'); ?>
            <input type="hidden" name="pimex_samples_action" value="add">
            <input type="hidden" name="pimex_samples_ids" value="[]" class="ps-ids">
            <details class="ps-details" open>
                <summary class="ps-summary-toggle"><span>Twój zestaw <span class="ps-count">0</span></span><span class="ps-mobile-total">0,00 zł</span><span class="ps-chevron" aria-hidden="true">⌄</span></summary>
                <div class="ps-summary-body">
                    <p class="ps-empty-selection">Zaznacz pierwszą próbkę. Możesz łączyć materiały różnych producentów.</p>
                    <ul class="ps-selected"></ul>
                    <div class="ps-totals" aria-live="polite">
                        <p><span class="ps-quantity-label">Próbki · 0 szt.</span><strong class="ps-subtotal">0,00 zł</strong></p>
                        <p><span>Wysyłka w Polsce</span><strong class="ps-shipping">—</strong></p>
                        <p class="ps-total-row"><span>Razem brutto</span><strong class="ps-grand-total">0,00 zł</strong></p>
                    </div>
                    <p class="ps-feedback" role="status" aria-live="polite"></p>
                    <button type="submit" class="button alt ps-submit" disabled>Dodaj zestaw do koszyka →</button>
                    <button type="button" class="button ps-clear">Wyczyść zestaw</button>
                    <p class="ps-note">Maksymalnie <?php echo esc_html($config['max']); ?> różnych próbek, po jednej sztuce każdego modelu i koloru. Pełne deski mają osobny koszt transportu.</p>
                </div>
            </details>
        </form>
    </div>
    <noscript><p>Włącz JavaScript, aby wybrać próbki. Możesz też skontaktować się z PIMEX w sprawie zamówienia.</p></noscript>
</section>
