=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.7.0
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.7.0 =
Mniej powtórnych odczytów produktów i wariantów, zbiorczy cache WordPressa,
lżejszy HTML, skonsolidowany CSS i ograniczone ładowanie skryptów.
Komunikaty koszyka ponownie korzystają z ustawień motywu.
Szczegóły i wyniki lokalnych testów: AKTUALIZACJA-2.7.0.txt.
