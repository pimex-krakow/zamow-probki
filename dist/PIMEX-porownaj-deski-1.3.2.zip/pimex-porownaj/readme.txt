=== PIMEX — porównaj deski ===
Contributors: pimex
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.3.2

== Description ==
Osobna porównywarka pełnych produktów i wariantów sklepu PIMEX.
Styl strony próbek, filtry atrybutów, grupy kolorów z wtyczki próbek,
wybór 2–6 produktów, tabela parametrów i aktualne ceny WooCommerce.
Nie zmienia układu WoodMart ani kodu wtyczki próbek.

== Installation ==
Aktywuj obok wtyczki próbek. WooCommerce > Porównaj deski:
wybierz kategorie, utwórz szkic strony, przygotuj katalog i sprawdź podgląd.
Shortcode: [pimex_porownaj]. Szczegóły: START-TUTAJ.txt i INSTRUKCJA.txt.

== Changelog ==
= 1.3.2 =
Tabela pełnej wysokości, bez wewnętrznego przewijania w pionie.
Pozostawione przewijanie poziome i przyklejona kolumna parametrów.
Usunięto wiersze Nazwa produktu, Typ elementu, SKU, Dostępność oraz opcję
ukrywania jednakowych parametrów. Nazwy modeli pozostają przy zdjęciach.

= 1.3.1 =
Trzy niezależne rodzaje desek, usunięty filtr Typ elementu, wybór na górze
kafelka i podkreślony link na dole. Edytowalna kolejność filtrów w panelu,
łącznie z ceną za mb/m², bez przebudowy katalogu po zmianie kolejności.

= 1.3.0 =
Dwa stałe przyciski nad Filtry, wspólna kategoria elewacji i lameli, limit
6 produktów, nawigacja tabeli i filtry cen Od/Do za mb i m². Właściciel
potwierdził ceny za sztukę; przeliczenia bazują na rzeczywistych wymiarach.

= 1.2.0 =
Jeden kafelek dla wariantów długości tego samego produktu i profilu.
Lista długości i aktualny zakres ich cen. Wyróżnione rodzaje desek nad
pozostałymi filtrami. Wymaga ponownego przygotowania katalogu po aktualizacji.

= 1.1.0 =
Aktualizacja istniejącej porównywarki: widoczny przycisk nad produktami,
dolny pasek mobilny, wspólny stan liczników i tabeli, niezależność od cookies
WoodMart, noindex skonfigurowanej strony i integracja z mapami WordPress/Yoast.
Zachowane kategorie, katalog, strona i shortcode.

= 1.0.0 =
Pierwsza wersja niezależnej strony porównania produktów PIMEX.
