<?php defined('ABSPATH') || exit; ?>
<section class="pimex-samples ps-v2" aria-label="Wybór próbek PIMEX">
    <script type="application/json" class="ps-config"><?php echo wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
    <header class="ps-hero">
        <h2>Sprawdź materiał przed zakupem</h2>
        <p>Porównaj kolory i strukturę w swoim domu. Zaznacz próbki, które chcesz zamówić.</p>
    </header>
    <?php if (!$config['enabled']) : ?><p class="ps-status" role="status">Zamawianie próbek jest chwilowo wyłączone. Możesz obejrzeć dostępne materiały.</p><?php endif; ?>
    <div class="ps-layout">
        <aside class="ps-filter-panel" aria-label="Filtry próbek">
            <details class="ps-mobile-filters" open><summary>Filtry<span class="ps-more-count"></span></summary>
            <div class="ps-filter-content">
            <details class="ps-filter-section"><summary class="ps-filter-title">Zastosowanie</summary>
    <div class="ps-groups ps-filter-options" role="group" aria-label="Wybierz zastosowanie">
        <label class="ps-dimension-option"><input type="checkbox" value=""><span>Wszystkie próbki <small class="ps-group-count"></small></span></label>
        <label class="ps-dimension-option"><input type="checkbox" value="tarasy"><span>Deski tarasowe <small class="ps-group-count"></small></span></label>
        <label class="ps-dimension-option"><input type="checkbox" value="elewacje"><span>Deski elewacyjne <small class="ps-group-count"></small></span></label>
        <label class="ps-dimension-option"><input type="checkbox" value="lamele"><span>Lamele elewacyjne <small class="ps-group-count"></small></span></label>
    </div></details>
            <div class="ps-filters">
                <details class="ps-filter-section"><summary class="ps-filter-title">Producent</summary><div class="ps-brand ps-filter-options" role="group" aria-label="Producent"></div></details>
                <details class="ps-filter-section"><summary class="ps-filter-title">Kolor</summary><div class="ps-color-filter ps-filter-options" role="group" aria-label="Kolor"><label class="ps-dimension-option"><input type="checkbox" value=""><span>Wszystkie kolory</span></label>
                    <?php foreach (Pimex_Samples_Catalog::shades() as $key => $label) : ?><label class="ps-dimension-option"><input type="checkbox" value="<?php echo esc_attr($key); ?>"><span><?php echo esc_html($label); ?></span></label><?php endforeach; ?>
                </div></details>
            </div>
            <div class="ps-extra-filters">
                <details class="ps-filter-section"><summary class="ps-filter-title">Konstrukcja</summary><div class="ps-construction ps-filter-options" role="group" aria-label="Konstrukcja"><label class="ps-dimension-option"><input type="checkbox" value=""><span>Wszystkie konstrukcje</span></label><label class="ps-dimension-option"><input type="checkbox" value="solid"><span>Pełna</span></label><label class="ps-dimension-option"><input type="checkbox" value="hollow"><span>Komorowa</span></label></div></details>
                <details class="ps-filter-section"><summary class="ps-filter-title">Powłoka</summary><div class="ps-coating ps-filter-options" role="group" aria-label="Powłoka"><label class="ps-dimension-option"><input type="checkbox" value=""><span>Wszystkie</span></label><label class="ps-dimension-option"><input type="checkbox" value="coated"><span>Z powłoką polimerową</span></label><label class="ps-dimension-option"><input type="checkbox" value="uncoated"><span>Bez powłoki polimerowej</span></label></div></details>
                <details class="ps-filter-section"><summary class="ps-filter-title">Powierzchnia</summary><div class="ps-surface ps-filter-options" role="group" aria-label="Powierzchnia"></div></details>
                <details class="ps-filter-section"><summary class="ps-filter-title">Materiał</summary><div class="ps-material ps-filter-options" role="group" aria-label="Materiał"></div></details>
                <div class="ps-dimension-filter">
                    <details class="ps-dimension" data-axis="width">
                        <summary aria-label="Szerokość deski: Wszystkie szerokości"><span class="ps-filter-title">Szerokość deski</span></summary><span class="ps-dimension-value" aria-live="polite" hidden>Wszystkie szerokości</span>
                        <div class="ps-dimension-options" role="group" aria-label="Szerokość deski — wybierz wartości"></div>
                    </details>
                </div>
                <div class="ps-dimension-filter">
                    <details class="ps-dimension" data-axis="length">
                        <summary aria-label="Długość deski: Wszystkie długości"><span class="ps-filter-title">Długość deski</span></summary><span class="ps-dimension-value" aria-live="polite" hidden>Wszystkie długości</span>
                        <div class="ps-dimension-options" role="group" aria-label="Długość deski — wybierz wartości"></div>
                    </details>
                </div>
                <div class="ps-dimension-filter">
                    <details class="ps-dimension" data-axis="thickness">
                        <summary aria-label="Grubość deski: Wszystkie grubości"><span class="ps-filter-title">Grubość deski</span></summary><span class="ps-dimension-value" aria-live="polite" hidden>Wszystkie grubości</span>
                        <div class="ps-dimension-options" role="group" aria-label="Grubość deski — wybierz wartości"></div>
                    </details>
                </div>
            </div><p>Wymiary w mm. Możesz wybrać kilka opcji. Deski na wymiar pasują do każdej długości. Zamawiasz próbkę materiału.</p>
            <button type="button" class="button ps-reset-filters">Wyczyść filtry</button>
            </div></details>
        </aside>
        <div class="ps-catalog">
            <div class="ps-result-line"><p class="ps-results" aria-live="polite"></p><div class="ps-catalog-tools"><button type="button" class="button ps-search-toggle" aria-label="Szukaj próbek" title="Szukaj próbek" aria-expanded="false"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 5 5"></path></svg></button><button type="button" class="button ps-reset-filters">Wyczyść filtry</button></div></div>
            <div class="ps-search-box" hidden><input class="ps-search" type="search" aria-label="Model, producent lub kolor" placeholder="Szukaj modelu, producenta lub koloru" autocomplete="off"></div>
            <div class="ps-active-filters" aria-label="Aktywne filtry" hidden></div>
            <div class="ps-grid"></div>
            <div class="ps-empty" hidden><h3>Nie znaleźliśmy takich próbek</h3><p>Zmień model, producenta, kolor lub zastosowanie.</p><button type="button" class="button ps-reset-filters">Pokaż wszystkie próbki</button></div>
            <nav class="ps-pagination" aria-label="Strony wyboru próbek"></nav>
            <p class="ps-photo-note">Zdjęcia przedstawiają pełny produkt lub realizację. Otrzymasz próbkę materiału. Kolor na ekranie może różnić się od rzeczywistego.</p>
        </div>
        <form method="post" class="ps-order" action="<?php echo esc_url(get_permalink()); ?>">
            <?php wp_nonce_field('pimex_samples_order', 'pimex_samples_nonce'); ?>
            <input type="hidden" name="pimex_samples_action" value="add">
            <input type="hidden" name="pimex_samples_ids" value="[]" class="ps-ids">
            <div class="ps-details">
                <div class="ps-summary-heading"><h3>Twój zestaw</h3><span class="ps-count" aria-label="Liczba wybranych próbek">0</span></div>
                <div class="ps-summary-body">
                    <p class="ps-empty-selection">Zaznacz pierwszą próbkę. Możesz łączyć materiały różnych producentów.</p>
                    <ul class="ps-selected"></ul>
                    <div class="ps-totals" aria-live="polite">
                        <p><span class="ps-quantity-label">Próbki · 0 szt.</span><strong class="ps-subtotal">0,00 zł</strong></p>
                        <p><span>Wysyłka w Polsce</span><strong class="ps-shipping">—</strong></p>
                        <p class="ps-total-row"><span>Razem brutto</span><strong class="ps-grand-total">0,00 zł</strong></p>
                    </div>
                    <p class="ps-feedback" role="status" aria-live="polite"></p>
                    <button type="submit" class="button alt ps-submit" disabled>Dodaj zestaw do koszyka →</button>
                    <button type="button" class="button ps-clear">Wyczyść zestaw</button>
                    <p class="ps-note">Maksymalnie <?php echo esc_html($config['max']); ?> różnych próbek, po jednej sztuce każdego modelu i koloru.</p>
                </div>
            </div>
        </form>
    </div>
    <noscript><p>Włącz JavaScript, aby wybrać próbki. Możesz też skontaktować się z PIMEX w sprawie zamówienia.</p></noscript>
</section>
