=== PIMEX — wybór próbek ===
Contributors: pimex
Requires PHP: 7.4
Stable tag: 2.9.0
Requires Plugins: woocommerce

== Description ==
Wybór próbek z istniejących produktów WooCommerce. Filtry wymiarów, koloru,
producenta i konstrukcji, niezależna dostępność próbek, edytowalne ceny,
podsumowanie i osobna dostawa zestawu.

== Installation ==
Aktualizuj istniejącą wtyczkę przez przesłanie ZIP i zastąpienie bieżącej wersji.
Ustawienia znajdują się w WooCommerce > Próbki PIMEX.
Nie twórz nowej strony/produktu; zachowaj istniejący shortcode [pimex_probki].

== Changelog ==
= 2.9.0 =
Usunięto skanowanie wariantów przy wyświetlaniu przycisku produktu.
Trwały cache katalogu, odświeżanie w tle i blokada równoległych przebudów.
Zasoby ładowane wyłącznie tam, gdzie renderują się elementy próbek.
Przycisk Zamów próbkę (cena) dodaje próbkę bezpośrednio do koszyka.
Klikalne Wszystkie w wymiarach; lupka nad próbkami; spójne, pogrubione nagłówki.
Szczegóły testów: AKTUALIZACJA-2.9.0.txt.
