(function () {
    'use strict';
    // Submit only sample data. Theme AJAX handlers must never add a full board for this button.
    document.addEventListener('click', function (event) {
        const button = event.target.closest('button.pimex-sample-cta[data-pimex-direct-url]');
        if (!button || !button.form) return;
        event.preventDefault(); event.stopImmediatePropagation();
        if (button.disabled) return;
        const source = button.form;
        const form = document.createElement('form');
        form.method = 'post'; form.action = button.dataset.pimexDirectUrl; form.hidden = true;
        const fields = {
            pimex_samples_direct: button.value,
            pimex_sample_direct_nonce: (source.querySelector('[name="pimex_sample_direct_nonce"]') || {}).value || '',
            variation_id: (source.querySelector('[name="variation_id"]') || {}).value || '0'
        };
        Object.keys(fields).forEach(function (name) {
            const input = document.createElement('input'); input.type = 'hidden'; input.name = name; input.value = fields[name]; form.append(input);
        });
        button.disabled = true;
        document.body.append(form); form.submit();
    }, true);
    window.addEventListener('pageshow', function () {
        document.querySelectorAll('button.pimex-sample-cta').forEach(button => { button.disabled = false; });
    });
}());
