<?php
defined('ABSPATH') || exit;
final class Pimex_Compare_Attributes {
    public static function normalize($text) { return strtolower(remove_accents(wp_strip_all_tags((string) $text))); }
    private static function key($value) { return preg_replace('/^pa-/', '', sanitize_title(str_replace('_','-', $value))); }
    public static function values($product, $names) {
        foreach ($product->get_attributes() as $key=>$attribute) {
            $name = is_object($attribute) && method_exists($attribute,'get_name') ? $attribute->get_name() : $key;
            $label = wc_attribute_label($name, $product);
            if (!in_array(self::key($name),$names,true) && !in_array(self::key($label),$names,true)) { continue; }
            if (is_object($attribute)) {
                if ($attribute->is_taxonomy()) {
                    $terms = $attribute->get_terms();
                    $values = $terms && !is_wp_error($terms) ? wp_list_pluck($terms,'name') : array();
                } else { $values = $attribute->get_options(); }
            } else {
                $value = $product->get_attribute($name);
                if ($value !== '' && taxonomy_exists($name)) {
                    $term = get_term_by('slug', $value, $name);
                    if ($term && !is_wp_error($term)) { $value = $term->name; }
                }
                $values = preg_split('/\s*[,|]\s*/u', (string) $value);
            }
            return array_values(array_unique(array_filter(array_map(function($v){return trim(wp_strip_all_tags((string)$v));},$values),function($v){return $v!=='';})));
        }
        return array();
    }
    public static function field($product, $parent, $names) {
        $values = $product->get_id() !== $parent->get_id() ? self::values($product,$names) : array();
        return $values ?: self::values($parent,$names);
    }
    public static function numbers($text, $unit='mm') {
        $text=self::normalize($text);
        if (preg_match('/(mm|cm|m)\s*$/',$text,$m)) { $unit=$m[1]; }
        preg_match_all('/(\d+(?:[.,]\d+)?)\s*(mm|cm|m)?(?![a-z])/',$text,$matches,PREG_SET_ORDER);
        $values=array();
        foreach($matches as $m){$u=!empty($m[2])?$m[2]:$unit;$v=(float)str_replace(',','.',$m[1])*($u==='m'?1000:($u==='cm'?10:1));if($v>0){$values[]=round($v,3);}}
        $values=array_values(array_unique($values));sort($values,SORT_NUMERIC);return $values;
    }
    public static function is_dimension_key($value,$name) {
        return (bool)preg_match('/^'.preg_quote($name,'/').'(?:-(?:deski|produktu))?(?:-(?:mm|cm|m))?$/',self::key($value));
    }
    public static function dimensions($product, $parent, $name) {
        foreach (array($product,$parent) as $p) {
            foreach($p->get_attributes() as $key=>$attribute) {
                $key=is_object($attribute)&&method_exists($attribute,'get_name')?$attribute->get_name():$key;
                $label=wc_attribute_label($key,$p);$slug=self::key($label);$raw=self::key($key);
                if(!self::is_dimension_key($key,$name)&&!self::is_dimension_key($label,$name)){continue;}
                $unit=preg_match('/-(mm|cm|m)$/',$raw,$m)||preg_match('/-(mm|cm|m)$/',$slug,$m)?$m[1]:'mm';
                $values=self::numbers($p->get_attribute($key),$unit);
                if($values){return $values;}
            }
        }
        return array();
    }
    public static function shades() {
        return array('grey'=>'Szarości i antracyty','brown'=>'Brązy i odcienie drewna','beige'=>'Beże i kremy','red'=>'Rudości i czerwienie','black'=>'Czernie');
    }
    public static function color_groups($text) {
        $text=self::normalize($text); if(preg_match('/\b(basalt|antique)\b/',$text)){return array();}
        $rules=array('grey'=>'anthracite|anthracyt|antracyt|graphite|grey|gray|szary|szara|grafitowy|grafit',
            'brown'=>'teak|walnut|oak|dab|debowy|orzech|braz|brazowy','beige'=>'cream latte|cream|bezowy|bez|kremowy|krem',
            'red'=>'copper|red cedar|oranz|miedziany|czerwony|rudy','black'=>'ebony|czarny|black|burnt wood');
        $out=array();foreach($rules as $key=>$words){if(preg_match('/(?<![a-z])(?:'.$words.')(?![a-z])/',$text)){$out[]=$key;}}return $out;
    }
    public static function custom($product,$parent) {
        $values=self::field($product,$parent,array('produkcja-na-wymiar','na-wymiar','dlugosc-na-wymiar'));
        // Parent's affirmative flag also applies to all its variants.
        $values=array_merge($values,self::values($parent,array('produkcja-na-wymiar','na-wymiar','dlugosc-na-wymiar')));
        foreach($values as $value){foreach(preg_split('/[|;,]/',self::normalize($value)) as $v){if(in_array(trim($v),array('tak','yes','true','1'),true)){return true;}}}
        foreach(self::field($product,$parent,array('dlugosc','dlugosc-mm','dlugosc-m')) as $v){if(preg_match('/^(produkcja )?na wymiar$/',self::normalize($v))){return true;}}
        return false;
    }
}
