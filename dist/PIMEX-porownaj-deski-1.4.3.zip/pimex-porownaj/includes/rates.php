<?php
defined('ABSPATH') || exit;
/** All PIMEX board prices are per piece, as confirmed by the shop owner. */
final class Pimex_Compare_Rates {
    public static function option($product) {
        $parent=Pimex_Compare_Catalog::parent($product);
        $out=array('id'=>$product->get_id(),'mb'=>null,'m2'=>null,'area_basis'=>'');
        if(!$parent||!is_numeric($product->get_price())){return $out;}
        $length=Pimex_Compare_Attributes::dimensions($product,$parent,'dlugosc');
        // An unspecified length cannot be inferred from a parent's multi-value attribute.
        if(count($length)!==1||!is_finite($length[0])||$length[0]<=0){return $out;}
        $price=(float)wc_get_price_to_display($product);if(!is_finite($price)||$price<0){return $out;}
        $decimals=wc_get_price_decimals();$meters=$length[0]/1000;
        $out['mb']=round($price/$meters,$decimals);
        $width=Pimex_Compare_Attributes::dimensions($product,$parent,'szerokosc-krycia');
        $basis='Szerokość krycia';
        if(!$width){$width=Pimex_Compare_Attributes::dimensions($product,$parent,'szerokosc');$basis='Szerokość deski';}
        if(count($width)===1&&is_finite($width[0])&&$width[0]>0){$out['m2']=round($price/($meters*$width[0]/1000),$decimals);$out['area_basis']=$basis.' '.$width[0].' mm';}
        return $out;
    }
    public static function summarize($products) {
        $options=array_map(array(__CLASS__,'option'),$products);$ranges=array();
        foreach(array('mb','m2') as $unit){
            $values=array();foreach($options as $option){if($option[$unit]!==null){$values[]=$option[$unit];}}
            // A partial range must not pretend to describe every length in the model.
            $ranges[$unit]=count($values)===count($products)&&$values?array('min'=>min($values),'max'=>max($values)):null;
        }
        $basis=array_values(array_unique(array_filter(array_column($options,'area_basis'))));
        return array('unit_options'=>$options,'rates'=>$ranges,'area_basis'=>implode(' / ',$basis));
    }
}
