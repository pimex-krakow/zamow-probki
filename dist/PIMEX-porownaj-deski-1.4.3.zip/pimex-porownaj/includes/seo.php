<?php
defined('ABSPATH') || exit;
/** Personal selection tools do not need separate search-result entries. */
final class Pimex_Compare_SEO {
    public static function boot() {
        add_filter('wp_robots', array(__CLASS__, 'robots'));
        add_filter('wpseo_robots', array(__CLASS__, 'yoast_robots'));
        add_filter('wpseo_sitemap_entry', array(__CLASS__, 'yoast_entry'), 10, 3);
        add_filter('wp_sitemaps_posts_query_args', array(__CLASS__, 'sitemap'), 10, 2);
    }
    public static function is_page() {
        $id = (int) Pimex_Compare::options()['page'];
        return $id > 0 && is_singular('page') && get_queried_object_id() === $id;
    }
    public static function robots($robots) {
        if (self::is_page()) { unset($robots['index']); $robots['noindex'] = true; }
        return $robots;
    }
    public static function yoast_robots($robots) {
        if (!self::is_page() || !is_string($robots)) { return $robots; }
        if (preg_match('/(?:^|[,\s])noindex(?:[,\s]|$)/', $robots)) { return $robots; }
        $robots = preg_replace('/\bindex\b/', 'noindex', $robots, 1, $count);
        return $count ? $robots : 'noindex' . ($robots !== '' ? ', ' . $robots : ', follow');
    }
    public static function yoast_entry($entry, $type, $object) {
        $id = (int) Pimex_Compare::options()['page'];
        return $id > 0 && is_object($object) && isset($object->ID) && (int) $object->ID === $id ? false : $entry;
    }
    public static function sitemap($args, $post_type) {
        $id = (int) Pimex_Compare::options()['page'];
        if ($id > 0 && $post_type === 'page') {
            $args['post__not_in'] = array_values(array_unique(array_merge((array) ($args['post__not_in'] ?? array()), array($id))));
        }
        return $args;
    }
}
