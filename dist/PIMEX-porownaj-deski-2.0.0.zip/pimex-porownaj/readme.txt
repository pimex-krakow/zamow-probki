=== PIMEX — porównaj deski ===
Contributors: pimex
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 2.0.0

== Description ==
Wspólny katalog desek, porównanie do 6 modeli i niezależny zestaw próbek.
Dotychczasowy panel filtrów i ustawianie atrybutów w WooCommerce.
Współpracuje z aktywną PIMEX — wybór próbek 3.0.6, zachowując jej ceny,
limity, koszyk, wysyłkę i obsługę zamówień. Nie modyfikuje produktów źródłowych.

== Installation ==
Zastąp dotychczasową wtyczkę pimex-porownaj. Pozostaw aktywną wtyczkę próbek.
WooCommerce > Porównaj deski: kategorie, filtry i tabela.
WooCommerce > Próbki PIMEX: ceny, wysyłka i dostępność próbek.
Shortcode: [pimex_porownaj], [pimex_probki] lub [pimex_dobierz_deski].
Użyj jednego na stronie. Szczegóły: START-TUTAJ.txt i INSTRUKCJA.txt.

== Changelog ==
= 2.0.0 =
Jeden wspólny katalog do porównania i zamawiania próbek, osobne wybory,
limity, liczniki i czyszczenie. Zachowany lewy panel i edycja filtrów.
Żywa dostępność próbek i istniejący atomowy mechanizm koszyka próbek.
Obsługa obu starych shortcode bez dublowania selektora.

= 1.4.3 =
Wyczyść wybór obok Wyczyść filtry nad katalogiem. Spójna nazwa na dole.
Czyszczenie wyboru zachowuje filtry, czyszczenie filtrów zachowuje wybór.
Link Zamów próbkę pod Zobacz produkt dla produktów z dostępną próbką.

= 1.4.2 =
Pełne strony po 4 rzędy: 20/16/12/8 produktów zależnie od liczby kolumn.
Czyste filtry przy otwarciu, odświeżeniu i powrocie Wstecz.
Spójna obsługa Długosc i jednostkowych aliasów długości desek drewnianych.
Warianty modelu pozostają razem; brakujące wymiary nie są zgadywane.

= 1.4.1 =
Mniejsze kafelki z jedną ceną za m², bez dodatkowej specyfikacji i dostępności.
5 kolumn na dużym ekranie, 4 na komputerze, 3 na tablecie i 2 na telefonie.
Zachowane parametry tabeli, suwaki, atrybuty i wybór sześciu modeli.

= 1.4.0 =
Suwaki zakresu cen za mb i m² z dwoma uchwytami i dokładnymi polami Od/Do.
Osobny wybór widoczności i kolejności filtrów oraz wierszy tabeli.
Globalne atrybuty WooCommerce dostępne bez zmian kodu, domyślnie wyłączone.
Po aktualizacji odśwież katalog, aby wczytać dodatkowe atrybuty.

= 1.3.2 =
Tabela pełnej wysokości, bez wewnętrznego przewijania w pionie.
Pozostawione przewijanie poziome i przyklejona kolumna parametrów.
Usunięto wiersze Nazwa produktu, Typ elementu, SKU, Dostępność oraz opcję
ukrywania jednakowych parametrów. Nazwy modeli pozostają przy zdjęciach.

= 1.3.1 =
Trzy niezależne rodzaje desek, usunięty filtr Typ elementu, wybór na górze
kafelka i podkreślony link na dole. Edytowalna kolejność filtrów w panelu,
łącznie z ceną za mb/m², bez przebudowy katalogu po zmianie kolejności.

= 1.3.0 =
Dwa stałe przyciski nad Filtry, wspólna kategoria elewacji i lameli, limit
6 produktów, nawigacja tabeli i filtry cen Od/Do za mb i m². Właściciel
potwierdził ceny za sztukę; przeliczenia bazują na rzeczywistych wymiarach.

= 1.2.0 =
Jeden kafelek dla wariantów długości tego samego produktu i profilu.
Lista długości i aktualny zakres ich cen. Wyróżnione rodzaje desek nad
pozostałymi filtrami. Wymaga ponownego przygotowania katalogu po aktualizacji.

= 1.1.0 =
Aktualizacja istniejącej porównywarki: widoczny przycisk nad produktami,
dolny pasek mobilny, wspólny stan liczników i tabeli, niezależność od cookies
WoodMart, noindex skonfigurowanej strony i integracja z mapami WordPress/Yoast.
Zachowane kategorie, katalog, strona i shortcode.

= 1.0.0 =
Pierwsza wersja niezależnej strony porównania produktów PIMEX.
