<?php
defined('ABSPATH') || exit;
/** UI adapter only. Prices, sample validation and atomic cart writes stay in the samples plugin. */
final class Pimex_Compare_Samples {
    public static function supported() {
        foreach(array('source','options','ready','add_samples') as $method){if(!is_callable(array('Pimex_Samples_1',$method))){return false;}}
        return true;
    }
    public static function boot() {
        add_action('wp_ajax_pimex_compare_sample_status',array(__CLASS__,'status'));
        add_action('wp_ajax_nopriv_pimex_compare_sample_status',array(__CLASS__,'status'));
        add_action('template_redirect',array(__CLASS__,'submit'),14);
        add_action('wp_footer',array(__CLASS__,'clear_after_order'));
        add_filter('pre_do_shortcode_tag',array(__CLASS__,'legacy_shortcode'),10,4);
    }
    public static function legacy_shortcode($return,$tag,$attributes=array(),$match=array()) {
        return $tag==='pimex_probki'&&self::supported()?Pimex_Compare::shortcode():$return;
    }
    public static function config() {
        $active=self::supported();$o=$active?Pimex_Samples_1::options():array();
        return array('active'=>$active,'enabled'=>$active&&Pimex_Samples_1::ready(),
            'price'=>$active?(float)$o['price']:0,'shipping'=>$active?(float)$o['shipping']:0,
            'max'=>max(1,min(50,(int)($o['max']??12))),
            'nonce'=>$active?wp_create_nonce('pimex_compare_samples_order'):'',
            'pickId'=>isset($_GET['pimex_pick'])&&is_string($_GET['pimex_pick'])&&strlen($_GET['pimex_pick'])<=18&&preg_match('/^[1-9][0-9]*$/D',$_GET['pimex_pick'])?(int)$_GET['pimex_pick']:0,
            'storage'=>'pimex-unified-samples-v1-'.get_current_blog_id());
    }
    public static function source($id) {
        if(!self::supported()){return null;}
        $sample=Pimex_Samples_1::source($id,true);if(!$sample){return null;}
        $image=!empty($sample['image'])?wp_get_attachment_image_url($sample['image'],'woocommerce_thumbnail'):'';
        return array('id'=>(int)$id,'key'=>(string)$sample['key'],'label'=>wp_strip_all_tags($sample['label']),
            'image'=>$image?:wc_placeholder_img_src(),'available'=>!empty($sample['available']));
    }
    /** Public read-only, at most 24 explicit product IDs. Never builds a product catalog. */
    public static function status() {
        $raw=$_POST['ids']??'';
        if(!is_string($raw)||strlen($raw)>512||($raw!==''&&!preg_match('/^[1-9][0-9]*(?:,[1-9][0-9]*)*$/D',$raw))){wp_send_json_error(array('message'=>'Nieprawidłowe produkty.'),400);}
        $ids=$raw===''?array():array_values(array_unique(array_map('intval',explode(',',$raw))));
        if(count($ids)>24){wp_send_json_error(array('message'=>'Maksymalnie 24 produkty.'),400);}
        $items=array();foreach($ids as $id){$items[(string)$id]=self::source($id);}
        nocache_headers();wp_send_json_success(array('settings'=>self::config(),'items'=>$items));
    }
    public static function parse_ids($raw,$limit) {
        if(!is_string($raw)||strlen($raw)>2048){return false;}$ids=json_decode(wp_unslash($raw),true);
        if(!is_array($ids)||!$ids||count($ids)>min(50,$limit)){return false;}
        foreach($ids as $id){if((!is_int($id)&&!is_string($id))||!preg_match('/^[1-9][0-9]*$/D',(string)$id)){return false;}}
        return array_map('intval',$ids);
    }
    public static function submit() {
        if(Pimex_Compare::is_tool_page()){
            if(!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE',true);}nocache_headers();
        }
        if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||($_POST['pimex_compare_samples_action']??'')!=='add'){return;}
        $nonce=$_POST['pimex_compare_samples_nonce']??'';
        if(!is_string($nonce)||!wp_verify_nonce($nonce,'pimex_compare_samples_order')){wp_die('Sesja wygasła. Odśwież stronę i spróbuj ponownie.','',array('response'=>403));}
        $settings=self::config();$ids=self::parse_ids($_POST['pimex_compare_samples_ids']??null,$settings['max']);
        $id=(int)get_queried_object_id();$return=$id&&Pimex_Compare::is_tool_page()?get_permalink($id):get_permalink((int)Pimex_Compare::options()['page']);
        if(!$return){$return=wc_get_page_permalink('shop');}
        if(!$settings['enabled']||$ids===false){wc_add_notice('Sprawdź dostępność próbek i liczbę zaznaczeń.','error');wp_safe_redirect($return,303);exit;}
        if(!WC()->cart){wc_load_cart();}
        $result=Pimex_Samples_1::add_samples($ids);
        if($result!==true){wc_add_notice(is_string($result)?$result:'Nie udało się dodać zestawu próbek.','error');wp_safe_redirect($return,303);exit;}
        wc_add_notice('Wybrane próbki są w koszyku.','success');
        wp_safe_redirect(add_query_arg('probki_dodane','1',wc_get_cart_url()),303);exit;
    }
    public static function clear_after_order() {
        if(!function_exists('is_cart')||!is_cart()||empty($_GET['probki_dodane'])){return;}
        echo '<script>try{localStorage.removeItem('.wp_json_encode('pimex-unified-samples-v1-'.get_current_blog_id()).');}catch(e){}</script>';
    }
}
