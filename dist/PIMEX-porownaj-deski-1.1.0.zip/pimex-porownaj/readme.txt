=== PIMEX — porównaj deski ===
Contributors: pimex
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.1.0

== Description ==
Osobna porównywarka pełnych produktów i wariantów sklepu PIMEX.
Styl strony próbek, filtry atrybutów, grupy kolorów z wtyczki próbek,
wybór 2–4 produktów, tabela różnic i aktualne ceny WooCommerce.
Nie zmienia układu WoodMart ani kodu wtyczki próbek.

== Installation ==
Aktywuj obok wtyczki próbek. WooCommerce > Porównaj deski:
wybierz kategorie, utwórz szkic strony, przygotuj katalog i sprawdź podgląd.
Shortcode: [pimex_porownaj]. Szczegóły: START-TUTAJ.txt i INSTRUKCJA.txt.

== Changelog ==
= 1.1.0 =
Aktualizacja istniejącej porównywarki: widoczny przycisk nad produktami,
dolny pasek mobilny, wspólny stan liczników i tabeli, niezależność od cookies
WoodMart, noindex skonfigurowanej strony i integracja z mapami WordPress/Yoast.
Zachowane kategorie, katalog, strona i shortcode.

= 1.0.0 =
Pierwsza wersja niezależnej strony porównania produktów PIMEX.
