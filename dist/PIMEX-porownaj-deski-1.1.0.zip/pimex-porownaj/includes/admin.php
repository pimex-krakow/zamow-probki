<?php
defined('ABSPATH') || exit;
final class Pimex_Compare_Admin {
    public static function boot(){
        add_action('admin_menu',function(){add_submenu_page('woocommerce','Porównaj deski PIMEX','Porównaj deski','manage_woocommerce','pimex-compare',array(__CLASS__,'render'));});
        add_action('admin_post_pimex_compare_setup',array(__CLASS__,'save'));
        add_action('wp_ajax_pimex_compare_build_admin',array(__CLASS__,'build'));
    }
    public static function save(){
        if(!current_user_can('manage_woocommerce')){wp_die('Brak uprawnień.');}check_admin_referer('pimex_compare_setup');
        $o=Pimex_Compare::options();$slugs=array();
        foreach((array)($_POST['categories']??array()) as $slug){if(!is_string($slug)){continue;}$slug=sanitize_title(wp_unslash($slug));if(get_term_by('slug',$slug,'product_cat')){$slugs[]=$slug;}}
        if(!$slugs){wp_die('Wybierz przynajmniej jedną kategorię produktów.');}$o['categories']=array_values(array_unique($slugs));
        if(!empty($_POST['create_page'])&&(!$o['page']||get_post_status($o['page'])==='trash'||!get_post_status($o['page']))){
            $id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_title'=>'Dobierz i porównaj deski','post_name'=>'dobierz-i-porownaj-deski','post_content'=>'[pimex_porownaj]'),true);
            if(is_wp_error($id)){wp_die('Nie udało się utworzyć strony.');}$o['page']=$id;
        }
        update_option(Pimex_Compare::OPTION,$o,false);
        wp_safe_redirect(admin_url('admin.php?page=pimex-compare&saved=1'));exit;
    }
    public static function build(){
        if(!current_user_can('manage_woocommerce')){wp_send_json_error(array('message'=>'Brak uprawnień.'),403);}
        check_ajax_referer('pimex_compare_build','nonce');
        $state=!empty($_POST['restart'])?Pimex_Compare_Catalog::start():Pimex_Compare_Catalog::batch();
        if(isset($state['error'])){wp_send_json_error(array('message'=>$state['error']),500);}wp_send_json_success($state);
    }
    public static function render(){
        if(!current_user_can('manage_woocommerce')){return;}
        $o=Pimex_Compare::options();$snapshot=Pimex_Compare_Catalog::snapshot();$terms=get_terms(array('taxonomy'=>'product_cat','hide_empty'=>false));
        ?>
        <div class="wrap"><h1>Dobierz i porównaj deski PIMEX</h1>
        <p>Oddzielna strona porównania produktów. Dotychczasowy sklep i wtyczka próbek pozostają bez zmian.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="pimex_compare_setup"><?php wp_nonce_field('pimex_compare_setup'); ?>
        <h2>1. Wybierz produkty i przygotuj stronę</h2>
        <p><label for="pimex-compare-categories">Kategorie desek i lameli (można zaznaczyć kilka, przytrzymując Ctrl lub Cmd):</label></p>
        <select id="pimex-compare-categories" name="categories[]" multiple size="9" required>
        <?php if(!is_wp_error($terms)){foreach($terms as $term){?><option value="<?php echo esc_attr($term->slug); ?>" <?php selected(in_array($term->slug,$o['categories'],true)); ?>><?php echo esc_html($term->name.' ('.$term->slug.')'); ?></option><?php }} ?>
        </select>
        <?php if(!$o['page']||!get_post_status($o['page'])||get_post_status($o['page'])==='trash'){?><p><label><input type="checkbox" name="create_page" value="1" checked> Utwórz szkic strony „Dobierz i porównaj deski”</label></p><?php } ?>
        <?php submit_button('Zapisz i przygotuj stronę'); ?>
        </form>
        <h2>2. Przygotuj katalog</h2>
        <p>Katalog jest przygotowywany partiami. Nie zamykaj tego panelu do zakończenia. Poprzedni katalog pozostaje widoczny podczas odświeżania.</p>
        <p>Produkty w katalogu: <strong><?php echo esc_html(count($snapshot['items']??array())); ?></strong>.
        <?php if(!empty($snapshot['built'])){echo ' Ostatnie przygotowanie: '.esc_html(wp_date('d.m.Y H:i',$snapshot['built']));} ?></p>
        <?php if(class_exists('Pimex_Samples_1')){?><p>Grupy kolorów są odczytywane z wtyczki „PIMEX — wybór próbek”, wraz z ręcznymi przypisaniami. Aktualizują się przy ponownym przygotowaniu katalogu.</p><?php }else{?><p>Wtyczka próbek nie jest aktywna. Stosowane są reguły rozpoznawania kolorów; Basalt i Antique pozostają nieprzypisane do grup.</p><?php } ?>
        <button type="button" class="button button-primary" id="pimex-compare-build">Przygotuj / odśwież katalog</button>
        <p id="pimex-compare-progress" role="status" aria-live="polite"></p>
        <h2>3. Sprawdź i opublikuj</h2>
        <?php if($o['page']&&get_post_status($o['page'])&&get_post_status($o['page'])!=='trash'){?><p><a class="button" href="<?php echo esc_url(get_edit_post_link($o['page'])); ?>">Edytuj / opublikuj stronę</a> <a class="button" href="<?php echo esc_url(get_preview_post_link($o['page'])); ?>">Podgląd strony</a></p><?php } ?>
        <p>Shortcode: <code>[pimex_porownaj]</code>. Po sprawdzeniu strony opublikuj ją i dodaj do menu. Nie umieszczaj shortcode na całym sklepie.</p>
        <p>Strona wskazana w tym panelu jest oznaczona jako noindex i wyłączona z mapy stron WordPress / Yoast. Kategorie i produkty zachowują dotychczasowe ustawienia SEO.</p>
        <p>We wbudowanych ustawieniach strony WoodMart wybierz układ bez panelu bocznego, aby porównywarka wykorzystała szerokość treści.</p>
        <p>Ceny i dostępność są pobierane na bieżąco z WooCommerce dla widocznych produktów. Zdjęcia przedstawiają produkty sklepu. Porównanie nie zmienia koszyka.</p>
        </div>
        <script>
        (function(){const button=document.getElementById('pimex-compare-build'),status=document.getElementById('pimex-compare-progress');let active=false;
        button.addEventListener('click',async function(){if(active)return;active=true;button.disabled=true;let first=true;
        try{while(active){status.textContent='Przygotowywanie katalogu…';const data=new URLSearchParams({action:'pimex_compare_build_admin',nonce:<?php echo wp_json_encode(wp_create_nonce('pimex_compare_build')); ?>,restart:first?'1':''});
        const response=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:data});const result=await response.json();if(!response.ok||!result.success)throw new Error(result.data?.message||'Nie udało się przygotować katalogu.');
        const state=result.data;if(!state.busy)first=false;status.textContent=state.busy?'Katalog jest przygotowywany w tle. Czekam na zakończenie partii…':'Przetworzono '+state.processed+' produktów z '+state.total+'. Pozycje: '+state.items+'.';
        if(state.done){status.textContent='Gotowe. Katalog zawiera '+state.items+' produktów i wariantów. Możesz otworzyć podgląd strony.';break;}
        await new Promise(resolve=>setTimeout(resolve,state.busy?1800:150));}
        }catch(error){status.textContent='Nie udało się przygotować katalogu. Odśwież panel i spróbuj ponownie; poprzedni katalog pozostał dostępny.';}finally{active=false;button.disabled=false;}});})();
        </script>
        <?php
    }
}
